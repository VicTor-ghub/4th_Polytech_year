close all
I = imread('route.jpg');
% image(I)

B=rgb2gray(I);
% figure 
% image(B)
colormap(gray(255))

BW1 = edge(B,'canny');
% figure
% imshow(BW1)

%D�but algo

C=(B>150)*255;
image(C)

%Quadrillage

% img = B;  %# Load a sample 3-D RGB image
% img(10:10:end,:,:) = 0;       %# Change every tenth row to black
% img(:,10:10:end,:) = 0;       %# Change every tenth column to black
% imshow(img);                  %# Display the image

[x, y] = size(C);

a_max=60;
b_max=60;
a_min=0;
b_min=-60;
nb_a=70;
nb_b=70;

A=zeros(nb_a,nb_b);

[f , g]= find(C==255);

SA=size(f);

alpha= (a_max-a_min)/(nb_a-1);
      beta=a_min-alpha;
sigma= (nb_b-1)/(b_max-b_min);
      lambda=1-sigma*b_min;      
      
for i=1:SA(1)
  x=f(i);y=g(i);
  
  for u=1:nb_a;
      
      a=alpha*u+beta;
      
      b= -a*x +y;
      
      v= sigma*b + lambda;
      
      v=floor(v);
      
      if (b_min < b) && (b < b_max),
          
           A(u,v)= A(u,v) + 1;
           
      end
      
  end
  
end

[u , v]= find(A>100);
Droites=[alpha*u+beta (v-lambda)/sigma];
hold on
