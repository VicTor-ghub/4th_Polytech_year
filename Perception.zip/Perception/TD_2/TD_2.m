A = zeros(400, 300);
% image(A)
colormap(gray(255))

%First rct
A(100:140,50:70)=127;
% image(A)

%Second rct
A(150:190,50:70)=127;
% image(A)

%Third rct
A(125:170,70:200)=127;
image(A)

% BW1 = edge(A,'prewitt');
% BW2 = edge(A,'canny');
% BW3 = edge(A,'roberts');
% BW4= edge(A)
% 
%  figure
%  imshow(BW1)
% 
%  figure
%  imshow(BW2)
% 
%  figure
%  imshow(BW3)
% 
%  figure
%  imshow(BW4)

%Seuillage donn� pour B > � A
%B = 255x(A >H)

horizontal = -ones(3,3);
horizontal(2,:) = 2;
B=filter2(horizontal,A)
% figure
% imshow(B)

vertical = -ones(3,3);
vertical(:,2) = 2;
C=filter2(vertical,A)
% figure
% imshow(C)

D=B+C
figure
imshow(D)
