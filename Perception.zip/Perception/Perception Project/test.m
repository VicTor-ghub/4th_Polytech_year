%% PREPARATION DE L'ENVIRONNEMENT
clear all
clc
%% LECTURE

vidObj = VideoReader('Octo_Bouncer_POV.mp4'); 
%lis la video, renvoie la dur�e de la video, le temps de l'instant etudi�...

vidObj.CurrentTime =0;


%% Etude et traitement image par image de la video
while vidObj.hasFrame()
    video= vidObj.readFrame();
    figure(1)
    imshow(video);

    IMAGE_initiale=video;
    SI=size(IMAGE_initiale);  %affiche la taille de l'image en pixel 

    BALLS=IMAGE_initiale;
    
    %% Detection des bou�es (attention les pixels ne sont pas aussi pr�cis 
    %%que lors de l'analyse d'une image, la video est moins pr�cise et fait
    %%perdre de l'information
    
    %Find all the circles with radius r pixels in the range [15, 30].
    [centers,radii,metric] = imfindcircles(video,[20 60], ...
    'Sensitivity',0.9,'ObjectPolarity','bright');
    %Retain the five strongest circles according to the metric values.
    %centersStrong3 = centers(1:3); 
    %Draw the five strongest circle perimeters over the original image.
    viscircles(centers, radii,'EdgeColor','r');
    
    hold on
    
    
        %% affiche le temps actuel de la vid�o
    str2 = ['time = ',num2str(vidObj.CurrentTime)];
    text(1630, 1040 ,str2,'Color','white','FontSize',14)

    hold off

    pause(1.0/vidObj.FrameRate);
end