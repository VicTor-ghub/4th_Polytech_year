%Test_IA

boxImage = imread('ping_pong.jpg');
figure;
imshow(boxImage);
title('Image of a ball');

sceneImage = imread('scene.jpg');
figure;
imshow(sceneImage);
title('Image of a Scene');

boxPoints = detectSURFFeatures(boxImage);
scenePoints = detectSURFFeatures(sceneImage);

figure;
imshow(boxImage);
title('100 Strongest Feature Points from Box Image');
hold on;
plot(selectStrongest(boxPoints, 100));

figure;
imshow(sceneImage);
title('300 Strongest Feature Points from Scene Image');
hold on;
plot(selectStrongest(scenePoints, 300));