%https://www.mathworks.com/help/images/ref/videoviewer-app.html
%https://www.mathworks.com/solutions/image-video-processing/video-processing


v = VideoReader('Balls_falling_LQ.avi');

%implay('Balls_falling_LQ.avi'); 

i = 1;
a=readFrame(v);
imshow(a);
frame = zeros(240,320,3,191);
frame = cast(frame,'uint8');

while hasFrame(v)
    frame(1:240, 1:320, 1:3, i) = readFrame(v);
    
    i=i+1;    
end