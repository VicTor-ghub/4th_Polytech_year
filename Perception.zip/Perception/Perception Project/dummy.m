%-------------------------Initialisation de la vid�o----------------------%
clc
clear

vision = VideoReader('Octo_Bouncer.mp4');
% implay('Octo_Bouncer.mp4');

% Cr�ation du fichier d'�criture
new_vision = VideoWriter('new_vision.avi');

open(new_vision); 
 
%-------------------------------Processing--------------------------------%
for i= 1:10
%while hasFrame(vision)  
   
    % Read video frame 
    current_image = readFrame(vision);

    % D�tection de la balle sur chaque frame
    [centers,radii] = imfindcircles(current_image,[65 75], ...
    'Sensitivity',0.95,'ObjectPolarity','bright');

    % Dessin des contours 
    % h = viscircles(centers,radii); 

    % Display video frame to screen 
    % implay(current_image);
    
    % Write frame to final video file 
    writeVideo(new_vision, current_image);

end
close(new_vision)
    
implay('new_vision.avi');
 
% Dessin des contours 
h = viscircles(centers,radii); 
 
 
 
 
 
 
 

%  % Setup: create Video Reader and Writer 
%  videoFileReader = VideoReader('tilted_face.avi'); 
%  myVideo = VideoWriter('myFile.avi'); 
%  % Setup: create deployable video player and face detector 
%  depVideoPlayer = vision.DeployableVideoPlayer; 
%  faceDetector = vision.CascadeObjectDetector(); 
%  open(myVideo); 
% 
%  while hasFrame(videoFileReader)  
%      % read video frame 
%      videoFrame = readFrame(videoFileReader);  
%      % process frame 
%      bbox = faceDetector(videoFrame); 
%      videoFrame = insertShape(videoFrame, 'Rectangle', bbox);  
%      % Display video frame to screen 
%      depVideoPlayer(videoFrame);  
%      % Write frame to final video file 
%      writeVideo(myVideo, videoFrame);
%      pause(1/videoFileReader.FrameRate); 
%  end
%  close(myVideo)
% 

 
