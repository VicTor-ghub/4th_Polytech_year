%-------------------------Initialisation de la vid�o----------------------%
clc
clear

vision = VideoReader('Octo_Bouncer_POV.mp4');
% implay('Octo_Bouncer.mp4');

% Determine how many frames there are.
% numberOfFrames = vision.NumberOfFrames;

% Prepare a figure to show the images.
figure;

% Enlarge figure to full screen.
set(gcf, 'units','normalized','outerposition',[1 1 1920 1080]);

% Cr�ation du fichier d'�criture
new_vision = VideoWriter('new_vision.avi');

vidWidth = vision.Width;
vidHeight = vision.Height;

% open(new_vision); 
%-------------------------------Processing--------------------------------%
k = 1;
while hasFrame(vision)
   
    % Extract the frame from the movie structure.
	thisFrame = readFrame(vision); % Get the next frame in the video.

    % D�tection de la balle sur chaque frame
    [centers,radii,metric] = imfindcircles(thisFrame,[20 60], ...
    'Sensitivity',0.9,'ObjectPolarity','bright');

    % Keep the strongest circle
%     centersStrong = centers(1,:); 
%     radiiStrong = radii(1);
%     metricStrong = metric(1);
    
    % Dessin des contours 
    % figure
    % imshow(thisFrame);
    % viscircles(centers,radii);
    % f(frame)= getframe(figure);
    
    % Application du dessin � la frame
%     currAxes = axes;
%     image(thisFrame, 'Parent', currAxes);
%     currAxes.Visible = 'on';
%     viscircles(axes,centers,radii);
%     pause(1/vision.FrameRate);
    
    mov(k).cdata = readFrame(vision);
    k = k+1;
    viscircles(axes,centers,radii);
    % Write frame to final video file 
    %writeVideo(new_vision, thisFrame);

end
% close(new_vision)
    
% implay('new_vision.avi');
% 
% close all;

hf = figure;
set(hf,'position',[150 150 vidWidth vidHeight]);

movie(hf,mov,1,vision.FrameRate);
 