% Fonctions bwmorph

close all
I = imread('Teckel-scaled.jpeg');

B=rgb2gray(I);
% colormap(gray(255))
% 
C= (B>100)*255;
D= bwmorph(C,'skel',50); 
imshow(D)


