BW1 = imread('circles.png');
figure, imshow(BW1)
       

BW1 = bwmorph(BW1,'skul',Inf);
BW2 = bwmorph(BW3,'thin');

figure, imshow(BW2)
figure, imshow(BW3)