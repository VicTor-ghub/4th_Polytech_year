A = imread('gta.jpg');
%imshow(A)
B = imnoise(A);
%imshow(B)
C = rgb2gray(A);
imshow(C)
C=(C>150)*255;
masquehaut = -ones(3,3);
masquehaut(2,2)=8;
masquehaut=masquehaut/9;
filter2(masquehaut,C);
figure(2)
imshow(C)

masquebas = ones(3,3);
filter2(masquebas,C);
figure(3)
imshow(C)