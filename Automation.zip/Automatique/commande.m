% Commande

function train = commande(train,etat)

% R�cup�ration des variables de positions
train.q1= etat(1); 
train.q2= etat(2);
train.q3= etat(3);

% Positon des wagons
W1 = train.q2+train.L0;
W2 = train.q2+train.q3+2*train.L0;

% Update de la position du train
axis ([train.q1-2 train.q1+7 0 10])

sommets = [ train.q1-0.5 0;train.q1+0.5 0;train.q1+0.5 1;train.q1-0.5 0.6;
            train.q1+W1-0.5 0;train.q1+W1+0.5 0;train.q1+W1+0.5 1;train.q1+W1-0.5 1;
            train.q1+W2-0.5 0;train.q1+W2+0.5 0;train.q1+W2+0.5 1.1;train.q1+W2-0.5 1];

set(train.loco,'vertices', sommets);

drawnow;

end
