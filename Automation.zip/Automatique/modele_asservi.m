function [next_etat, obs, K0] = modele_asservi(train, etat, F,Te,obs)

% Equation de Lagrange

M= [train.m train.m2+train.m3 train.m3;
    train.m2+train.m3 train.m2+train.m3 train.m3;
    train.m3 train.m3 train.m3];

K= [0 0 0;
    0 train.k2 0;
    0 0 train.k3];

P= [train.f1 0 0;
    0 train.f2 0;
    0 0 train.f3];

% Repr�sentation d'Etat

A= [0 0 0 1 0 0;
    0 0 0 0 1 0;
    0 0 0 0 0 1;
    0 0 0 0 0 0;
    0 0 0 0 0 0;
    0 0 0 0 0 0];

A(4:6,1:3)= -inv(M)*K;

A(4:6,4:6)= -inv(M)*P;

B= zeros(6,1);
inverse = inv(M);

B(4:6,1)= inverse(1:3,1);

C = [0 0 0 1 0 0];
D = 0;

% Transformations discr�tes
AD= expm(A*Te);

expr= @(x) expm(A*x)*B;
BD= integral(expr,0,Te,'ArrayValued',true);

CD= C;
DD= D;
y = CD*obs + DD*F;

% Placement des p�les
P= [exp(Te*(-2)); exp(Te*(-2.4)); exp(Te*(-2.6)); exp(Te*(-2.8)); exp(Te*(-3)); exp(Te*(-3.2))];
K0= place(AD,BD,P);

%Output modele
next_etat = (AD-BD*K0)*etat + BD*F; % commande 

obs = (AD - K0'*CD)*obs + [BD K0']*[F;y]; % observateur

end