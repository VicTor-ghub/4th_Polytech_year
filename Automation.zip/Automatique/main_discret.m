%-----------------------------Initialisation------------------------------%
close all

% Initialisation du train
[train] = init();

% Affichage du train
grid on
hold on
set(gca,'xdir','reverse');
train = dessin(train);

% Variables temporelles
Te= 0.01; % Periode d'�chantillonage
t= 0;
t_max= 5;

% Variables d'etat et de commande
etat= [0;0;0;0;0;0];
F= 100;

%---------------------------Synth�se du syst�me---------------------------%

% Application des conditions intitiales
etat(1) = train.q1;
etat(2) = train.q2;
etat(3) = train.q3;
i=1; %suivi des variables

% Initialisation de l'observateur
obs = zeros(6,1);

%---------------------------Commande du syst�me---------------------------%

% Equation aux differences de l'echantillonnage temporel
while(t<t_max)
    
    % R�cup�ration du next_etat
    [etat,obs] = modele_discret(train,etat,-F,Te,obs);
    
    % Commande du train
    train = commande(train,etat);
    
    % R�cup�ration des positions/vitesses
    vitesse(i) = etat(4);
    ressort_2(i) = etat(2) - train.L0;
    ressort_3(i) = etat(3) - train.L0;
    
     % R�cup�ration des positions/vitesses de l'observateur
    vitesse_obs(i) = obs(4);
    ressort2_obs(i) = obs(2) - train.L0;
    ressort3_obs(i) = obs(3) - train.L0;
    
    t= t + Te;
    i= i+1;
end;

%--------------------------Affichage du syst�me---------------------------%

%Affichage des positions/vitesses
subplot(3,1,1); plot(vitesse);title('Vitesse');
subplot(3,1,2); plot(ressort_2);title('Ressort 2');
subplot(3,1,3); plot(ressort_3);title('Ressort 3');

%Affichage des positions/vitesses de l'observateur 
figure;
subplot(3,1,1); plot(vitesse_obs);title('VitesseObs');
subplot(3,1,2); plot(ressort2_obs);title('Ressort2 Obs');
subplot(3,1,3); plot(ressort3_obs);title('Ressort3 Obs');

