function [etat_dot,R] = modele(train, etat, F)

% Equation de Lagrange

M= [train.m train.m2+train.m3 train.m3;
    train.m2+train.m3 train.m2+train.m3 train.m3;
    train.m3 train.m3 train.m3];

K= [0 0 0;
    0 train.k2 0;
    0 0 train.k3];

P= [train.f1 0 0;
    0 train.f2 0;
    0 0 train.f3];

% Repr�sentation d'Etat

A= [0 0 0 1 0 0;
    0 0 0 0 1 0;
    0 0 0 0 0 1;
    0 0 0 0 0 0;
    0 0 0 0 0 0;
    0 0 0 0 0 0];

A(4:6,1:3)= -inv(M)*K;

A(4:6,4:6)= -inv(M)*P;

B= zeros(6,1);
inverse = inv(M);

B(4:6,1)= inverse(1:3,1);

C = [0 0 0 1 0 0];

% Observabilit� 
obs= obsv(A,C);

% Placement des p�les
P= [-2 -2.4 -2.6 -2.8 -3 -3.2];
R= place(A,B,P);

%Output modele
etat_dot = A*etat + B*F;       % sans retour d'�tat

% etat_dot = (A-B*R)*etat + B*F;  % avec retour d'�tat

end