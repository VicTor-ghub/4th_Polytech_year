% Initialisation

function [train] = init()

% Caract�ristiques du train
train.m1 = 3;
train.m2 = 1;
train.m3 = 1;
train.m = train.m1+train.m2+train.m3;
train.k2 = 80;
train.k3 = 80;
train.f1 = 3;
train.f2 = 5;
train.f3 = 5;
train.L0 = 2;
% Initialisation des variables de positions
train.q1= 0; 
train.q2= 0.1;
train.q3= -0.1;

end