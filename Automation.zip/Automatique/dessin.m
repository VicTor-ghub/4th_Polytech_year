% Dessin 

function train =dessin(train)

% Initialisation des variables de positions
% train.q1= etat(1); 
% train.q2= etat(2);
% train.q3= etat(3);

% Positon des wagons
W1 = train.q2+train.L0;
W2 = train.q2+train.q3+2*train.L0;

% Affichage du train
axis ([train.q1-5 train.q1+10 0 10])

sommets = [ train.q1-0.5 0;train.q1+0.5 0;train.q1+0.5 1;train.q1-0.5 0.6;
            train.q1+W1-0.5 0;train.q1+W1+0.5 0;train.q1+W1+0.5 1;train.q1+W1-0.5 1;
            train.q1+W2-0.5 0;train.q1+W2+0.5 0;train.q1+W2+0.5 1.1;train.q1+W2-0.5 1];
        
faces = [1 2 3 4; 5 6 7 8; 9 10 11 12];

color= [1 0 0; 0 1 0; 0 0 1];

train.loco = patch('vertices', sommets, 'faces', faces, 'FaceVertexCData',color, 'Facecolor', 'Flat');

end