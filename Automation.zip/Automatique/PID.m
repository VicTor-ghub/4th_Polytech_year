function [s, n, d] = PID(e, old_e, old_n, old_d, dt)

    % Coefficients du PID
    Kp = 3;
    Kd = 1.2;
    Ki = 10;

    tau = 0.05;
    p = Kp*e;
    n = Ki*dt/2 * (e + old_e) +old_n;
    d = 2*Kd/(2*tau+dt)*(e - old_e) + (2*tau-dt)/(2*tau+dt)*old_d;    
    
    s = p + n + d;

end