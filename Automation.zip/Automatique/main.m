%-----------------------------Initialisation------------------------------%

% Initialisation du train
[train] = init();

% Affichage du train
grid on
hold on
set(gca,'xdir','reverse');
train = dessin(train);

% Variables temporelles
dt= 0.01;
t= 0;
t_max= 5;

% Variables d'etat et de commande
etat= [0;0;0;0;0;0];
F= 100;

%---------------------------Synth�se du syst�me---------------------------%

% [etat_dot,R] = modele(train,etat,F);
% F = -R*etat;

% Application des conditions intitiales
etat(1) = train.q1;
etat(2) = train.q2;
etat(3) = train.q3;
i=1;                %suivi des variables

%---------------------------Commande du syst�me---------------------------%

%Int�gration des vitesses pour r�cup�ration de la position avec T=t+dt
while(t<t_max)
    
    [t45,q45]= ode45(@(t,etat)modele(train,etat,-F),[0 dt],etat);
    L45=length(t45);
    etat=q45(L45,:)';
    
    % Commande du train
    train = commande(train,etat);
    
    % R�cup�ration des positions/vitesses
    vitesse(i) = etat(4);
    ressort_2(i) = etat(2) - train.L0;
    ressort_3(i) = etat(3) - train.L0;
    
    t= t + dt;
    i= i+1;
end;

%Affichage des positions/vitesses
subplot(3,1,1); plot(vitesse);title('Vitesse');
subplot(3,1,2); plot(ressort_2);title('Ressort 2');
subplot(3,1,3); plot(ressort_3);title('Ressort 3');

