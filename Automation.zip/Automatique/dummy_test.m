% -------------------------------------Test----------------------------------------------%

% Initialisation du train
[train] = init();

% Equation de Lagrange

M= [train.m train.m2+train.m3 train.m3;
    train.m2+train.m3 train.m2+train.m3 train.m3;
    train.m3 train.m3 train.m3];

K= [0 0 0;
    0 train.k2 0;
    0 0 train.k3];

P= [train.f1 0 0;
    0 train.f2 0;
    0 0 train.f3];

% Repr�sentation d'Etat

A= [0 0 0 1 0 0;
    0 0 0 0 1 0;
    0 0 0 0 0 1;
    0 0 0 0 0 0;
    0 0 0 0 0 0;
    0 0 0 0 0 0];

A(4:6,1:3)= -inv(M)*K;

A(4:6,4:6)= -inv(M)*P;

B= zeros(6,1);
inverse = inv(M);

B(4:6,1)= inverse(1:3,1);

C = [0 0 0 1 0 0];
D = 0;

% Valeurs propres/ Vecteurs propres
[vecteurs_propres,valeurs_propres]=eig(A);

% Fonction de transfert
[NUM,DEN]= ss2tf(A,B,C,D);

% Observabilit� 
Obs= obsv(A,C);
rank(Obs)

% Commandabilit�
Command= ctrb(A,B);
rank(Command)

% Matrice compl�tement commandable mais pas coml�tement observable

% Placement des p�les
P= [-2 -2.4 -2.6 -2.8 -3 -3.2];
R= place(A,B,P);

% V�rification
[vecteurs_propres_d,valeurs_propres_d]=eig(A-B*R);  % OK: valeurs_propres_d = P 
