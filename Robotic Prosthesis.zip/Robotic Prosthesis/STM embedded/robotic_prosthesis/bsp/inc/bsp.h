/*
 * bsp.h
 *
 *  Created on: 22 sept. 2021
 *      Author: victor.rios
 */

#ifndef INC_BSP_H_
#define INC_BSP_H_

#include "stm32f0xx.h"

/*
 * LED driver functions
 */

void	BSP_LED_Init	(void);
void	BSP_LED_On	(void);
void	BSP_LED_Off	(void);
void	BSP_LED_Toggle	(void);

/*
 * UART driver functions
 */

void	BSP_Console_Init	(void);

/*
 * ADC functions
 */

void BSP_ADC_Init		(void);

/*
 * Timer functions
 */

void BSP_TIMER_Timebase_Init	(void);


/*
 * PWM fucntions
 */

void BSP_TIMER_PWM_Init(void);

/*
 * PWM fucntions
 */
void BSP_NVIC_Init(void);


#endif /* INC_BSP_H_ */
