/*
 * main.h
 *
 *  Created on: 22 sept. 2021
 *      Author: victor.rios
 */

#ifndef INC_MAIN_H_
#define INC_MAIN_H_

/*
 * printf() and sprintf() from printf-stdarg.c
 */

int my_printf	(const char *format, ...);
int my_sprintf	(char *out, const char *format, ...);

#endif /* INC_MAIN_H_ */
