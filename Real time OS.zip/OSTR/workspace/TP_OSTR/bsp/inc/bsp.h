/*
 * bsp.h
 *
 *  Created on: Sep 25, 2021
 *      Author: Victor
 */

#ifndef INC_BSP_H_
#define INC_BSP_H_

#include "stm32f0xx.h"

/*
 * LED driver functions
 */
void        BSP_LED_Init       (void);
void        BSP_LED_On         (void);
void        BSP_LED_Off        (void);
void        BSP_LED_Toggle     (void);

/*
 * Push-Button driver functions
 */
void        BSP_PB_Init        (void);
uint8_t     BSP_PB_GetState    (void);

/*
 * Debug Console init
 */
void        BSP_Console_Init   (void);	//Simple, with no DMA on RX channel

/*
 * NVIC interrupts fonctions
 */
void		BSP_NVIC_Init	   (void);

/*
 * Software counting delays
 */

void delay_ms	(uint32_t delay);


#endif /* INC_BSP_H_ */
