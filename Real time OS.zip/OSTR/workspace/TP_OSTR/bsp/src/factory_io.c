/*
 * factory_io.c
 *
 *  Created on: 5 d�c. 2020
 *      Author: Vico
 */

#include "stm32f0xx.h"
#include "factory_io.h"


/*
 * FACTORY_IO_Actuators_Set
 */

void FACTORY_IO_Actuators_Set(command_message_t message_com, uint32_t *cmd, uint8_t *trame)
{
	// Add the new command
	*cmd = (*cmd & ~message_com.act_msk) | message_com.act_cmd;

	// Prepare frame buffer
	trame[0] = TAG_ACTUATORS; 							// Actuators tag

	trame[1] = (uint8_t) (*cmd & 0x000000FF);			// data byte #1
	trame[2] = (uint8_t)((*cmd & 0x0000FF00) >>8U );	// data byte #2
	trame[3] = (uint8_t)((*cmd & 0x00FF0000) >>16U);	// data byte #2
	trame[4] = (uint8_t)((*cmd & 0xFF000000) >>24U);	// data byte #2

	trame[5] = 0x00;									// CRC (not yet implemented)
	trame[6] = '\n';									// End byte


//	// Return command buffer
//	return buffer;
//
//	// Send buffer over UART
//	for(n=0; n<7; n++)
//	{
//		while ( (USART2->ISR & USART_ISR_TC) != USART_ISR_TC);
//		USART2->TDR = buffer[n];
//	}
}


/*
 * FACTORY_IO_Sensors_Get
 */

uint32_t FACTORY_IO_Sensors_Get(void)
{
	uint32_t	sstates;

	// Build 32-bit sensors states representation
	sstates = 0x00000000;

	sstates |= rx_dma_buffer[1];
	sstates |= (rx_dma_buffer[2] <<8U );
	sstates |= (rx_dma_buffer[3] <<16U);
	sstates |= (rx_dma_buffer[4] <<24U);

	return sstates;
}


/*
 * Force Factory IO to send sensors and actuators states
 */

void FACTORY_IO_update(void)
{
	uint8_t	buffer[2];
	uint8_t	n;

	// Prepare frame buffer
	buffer[0] = TAG_UPDATE; 		// Update tag
	buffer[1] = '\n';

	// Send buffer over UART
	for(n=0; n<2; n++)
	{
		while ( (USART2->ISR & USART_ISR_TC) != USART_ISR_TC);
		USART2->TDR = buffer[n];
	}
}

