/*
 * event.h
 *
 *  Created on: 4 janv. 2022
 *      Author: victor.rios
 */

#ifndef INC_EVENT_H_
#define INC_EVENT_H_

#include "stm32f0xx.h"

// Evt function

uint8_t call_back_event(uint8_t indice, uint32_t sensor);

#endif /* INC_EVENT_H_ */
