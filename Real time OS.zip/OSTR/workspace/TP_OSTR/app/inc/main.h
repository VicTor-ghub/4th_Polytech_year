/*
 * main.h
 *
 *  Created on: 15 mai 2021
 *      Author: Victor
 */

#ifndef INC_MAIN_H_
#define INC_MAIN_H_

#define SUB_TAILLE 8
#define LENGHT 60
#define SENSOR_TABLE_SIZE 32

// All actuators in off state
#define Actuator_Off 0x00000000

/*
 * Actuators define
 */

#define Distrib_C 1
#define Tapis_Distrib_C 1 << 1
#define Blocage_Palettiseur 1 << 2
#define Porte 1 << 3
#define Poussoir 1 << 4
#define Clamp 1 << 5
#define Monter_asc 1 << 6
#define Descendre_asc 1 << 8
#define Asc_to_limit 1 << 9
#define Distrib_P 1 << 10
#define Charger_P 1 << 11
#define Tapis_C_vers_Palettiseur 1 << 12
#define Tourner_C 1 << 13
#define Decharger_Palettiseur 1 << 14
#define Charger_Palettiseur 1 << 16
#define Decharger_P 1 << 17
#define Tapis_Palette_vers_asc 1 << 18
#define Tapis_distrib_P 1 << 19
#define Tapis_Fin 1 << 20
#define Remover 1 << 21

/*
 * Sensors define
 */

#define Carton_distrib 1
#define Carton_envoye 1 << 1
#define Entree_Palletiseur 1 << 2
#define Porte_ouverte 1 << 3
#define Limite_poussoir 1 << 4
#define Clamped 1 << 5
#define Asc_etage_rdc 1 << 6
#define Asc_etage_1 1 << 8
#define Asc_etage_2 1 << 9
#define Sortie_P 1 << 10
#define Limite_porte 1 << 11
#define Asc_en_mvt 1 << 12
#define Entree_P 1 << 13
#define Butee_C 1 << 14

// Device header
#include "stm32f0xx.h"

// BSP functions
#include "bsp.h"

// FreeRTOS headers
#include "FreeRTOSConfig.h"
#include "FreeRTOS.h"
#include "task.h"
#include "timers.h"
#include "semphr.h"
#include "queue.h"
#include "event_groups.h"
#include "stream_buffer.h"
#include "event.h"
#include "factory_io.h"

// Global functions
int my_printf	(const char *format, ...);
int my_sprintf	(char *out, const char *format, ...);

// Global variables
uint8_t tx_dma_buffer[LENGHT];
uint8_t rx_dma_buffer[14];

//Subscribe function
//void subscribe(uint8_t sem_ID, uint8_t sensor_ID, uint8_t sensor_STATE);

#endif /* INC_MAIN_H_ */
