/*
 * main.c
 *
 *  Created on: Sep 25, 2021
 *      Author: Victor
 */

#include "main.h"

// Static functions
static void SystemClock_Config	(void);

// Global variables
uint32_t free_heap_size;

// FreeRTOS tasks
void vTask1 		(void *pvParameters);
void vTask2 		(void *pvParameters);
void vTask3 		(void *pvParameters);
void vTask4 		(void *pvParameters);
void vTaskPub		(void *pvParameters);
void vTask_Write    (void *pvParameters);

/*
* Kernel objects
*/
xQueueHandle xSubscribeQueue;	// Subscribe queue
xQueueHandle xCommandQueue; 	// Command queue

xSemaphoreHandle xSem1;
xSemaphoreHandle xSem2;
xSemaphoreHandle xSem3;
xSemaphoreHandle xSem4;

xSemaphoreHandle xSem_DMA_TC;

xSemaphoreHandle xTask3_to_Task2;
xSemaphoreHandle xTask2_to_Task1;
xSemaphoreHandle xTask4_to_Task2;
xSemaphoreHandle xTask2_to_Task3;

EventGroupHandle_t myEventGroup;

// Define Event Group flags
#define	BIT0	( (EventBits_t)( 0x01 <<0) )   // Not mandatory
#define BIT1	( (EventBits_t)( 0x01 <<1) )   // Provide friendly alias for individual event

// Subscribe message struct
typedef struct
{
	xSemaphoreHandle *sem_id; // Semaphore ID to use for publication

	uint8_t index; // Subscription index

	uint8_t (*cb_evt)(uint8_t, uint32_t); // Pointer on call-back function

} subscribe_message_t;

// Define the message_t type as subscribe_message_t
typedef subscribe_message_t message_t;

// Declare Timer Object
TickType_t	ticks;

// Trace User Events Channels
traceString ue1;

// Main program
int main()
{
	// Configure System Clock
	// SystemClock_Config();

	// Initialize LED and USER Button
	BSP_LED_Init();
	BSP_PB_Init();

	// Initialize Debug Console
	BSP_Console_Init();

	// Start Trace Recording
	vTraceEnable(TRC_START);

	// Create Semaphore object
	xSem1 = xSemaphoreCreateBinary();
	xSem2 = xSemaphoreCreateBinary();
	xSem3 = xSemaphoreCreateBinary();
	xSem4 = xSemaphoreCreateBinary();
	xSem_DMA_TC = xSemaphoreCreateBinary();
	xTask3_to_Task2 = xSemaphoreCreateBinary();
	xTask2_to_Task1 = xSemaphoreCreateBinary();
	xTask4_to_Task2 = xSemaphoreCreateBinary();
	xTask2_to_Task3 = xSemaphoreCreateBinary();

	// Create Event Group                   // <-- Create Event Group here
	myEventGroup = xEventGroupCreate();

	// Create Queue to hold subscribe messages
	xSubscribeQueue = xQueueCreate(10, sizeof(message_t *));

	// Create Queue to hold actuators messages
	xCommandQueue = xQueueCreate(10, sizeof(command_message_t *));

	// Register the Trace User Event Channels
	ue1 = xTraceRegisterString("ticks");

	// Create Tasks
	xTaskCreate(vTask1,		"Task_1", 		128, NULL, 1, NULL);
	xTaskCreate(vTask2,		"Task_2", 		128, NULL, 2, NULL);
	xTaskCreate(vTask3,		"Task_3", 		128, NULL, 3, NULL);
	xTaskCreate(vTask4,		"Task_4", 		128, NULL, 4, NULL);
	xTaskCreate(vTaskPub,	"Task_Pub", 	144, NULL, 5, NULL);
	xTaskCreate(vTask_Write,"vTask_Write",  128, NULL, 6, NULL);


	// Force Factory IO to send sensors and actuators states
	FACTORY_IO_update();

	// Start the Scheduler
	vTaskStartScheduler();

	while(1)
	{
		// The program should never be here...
	}
}

/*
 *	Task_1
 */
void vTask1 (void *pvParameters)
{
	message_t 	message_sub;
	message_t	*pm_sub;
	command_message_t 	message_com;
	command_message_t	*pm_com;

	uint8_t cnt = 0;

	// Take the semaphore once to make sure it is empty
	xSemaphoreTake(xSem1, 0);

	// Initialization
	message_com.act_cmd = 0;
	message_com.act_msk= 0;
	message_com.act_cmd |= Tapis_Distrib_C | Tapis_C_vers_Palettiseur | Blocage_Palettiseur | Charger_Palettiseur | Tapis_Fin | Tapis_distrib_P | Tapis_Palette_vers_asc | Remover;
	message_com.act_msk |= Tapis_Distrib_C | Tapis_C_vers_Palettiseur | Blocage_Palettiseur | Charger_Palettiseur | Tapis_Fin | Tapis_distrib_P | Tapis_Palette_vers_asc | Remover;
	pm_com = &message_com;
	xQueueSendToBack(xCommandQueue, &pm_com, 0);

	// Wait 100ms for debug
	vTaskDelay(10);

	while(1)
	{
		/*-----------------------------------------------------------*/

		// Actuator message Distib_carton
		message_com.act_cmd = Distrib_C;
		message_com.act_msk = Distrib_C;
		pm_com = &message_com;
		xQueueSendToBack(xCommandQueue, &pm_com, 0);

		// Subscribe message Carton envoyé
		message_sub.sem_id= &xSem1;
		message_sub.index = 0;
		message_sub.cb_evt= &call_back_event;
		// Send message to Subscribe Queue
		pm_sub = &message_sub;
		xQueueSendToBack(xSubscribeQueue, &pm_sub, 0);
		// Wait for Semaphore endlessly
		xSemaphoreTake(xSem1, portMAX_DELAY);

		// Subscribe message NOT Carton envoyé
		message_sub.sem_id= &xSem1;
		message_sub.index = 1;
		message_sub.cb_evt= &call_back_event;
		// Send message to Subscribe Queue
		pm_sub = &message_sub;
		xQueueSendToBack(xSubscribeQueue, &pm_sub, 0);
		// Wait for Semaphore endlessly
		xSemaphoreTake(xSem1, portMAX_DELAY);

		// Subscribe message Carton envoyé
		message_sub.sem_id= &xSem1;
		message_sub.index = 0;
		message_sub.cb_evt= &call_back_event;
		// Send message to Subscribe Queue
		pm_sub = &message_sub;
		xQueueSendToBack(xSubscribeQueue, &pm_sub, 0);
		// Wait for Semaphore endlessly
		xSemaphoreTake(xSem1, portMAX_DELAY);


		// Actuator message Distib_carton
		message_com.act_cmd = Actuator_Off;
		message_com.act_msk = Distrib_C;
		pm_com = &message_com;
		xQueueSendToBack(xCommandQueue, &pm_com, 0);

		/*-----------------------------------------------------------*/

		// Subscribe message Entrée palletiseur
		message_sub.sem_id= &xSem1;
		message_sub.index = 2;
		message_sub.cb_evt= &call_back_event;
		// Send message to Subscribe Queue
		pm_sub = &message_sub;
		xQueueSendToBack(xSubscribeQueue, &pm_sub, 0);
		// Wait for Semaphore endlessly
		xSemaphoreTake(xSem1, portMAX_DELAY);


		// Subscribe message NOT Entrée palletiseur
		message_sub.sem_id= &xSem1;
		message_sub.index = 3;
		message_sub.cb_evt= &call_back_event;
		// Send message to Subscribe Queue
		pm_sub = &message_sub;
		xQueueSendToBack(xSubscribeQueue, &pm_sub, 0);
		// Wait for Semaphore endlessly
		xSemaphoreTake(xSem1, portMAX_DELAY);

		// Subscribe message Entrée palletiseur
		message_sub.sem_id= &xSem1;
		message_sub.index = 2;
		message_sub.cb_evt= &call_back_event;
		// Send message to Subscribe Queue
		pm_sub = &message_sub;
		xQueueSendToBack(xSubscribeQueue, &pm_sub, 0);
		// Wait for Semaphore endlessly
		xSemaphoreTake(xSem1, portMAX_DELAY);

		/*-----------------------------------------------------------*/

		// Actuator message Blocage_Palettiseur
		message_com.act_cmd = Actuator_Off;
		message_com.act_msk = Blocage_Palettiseur;
		pm_com = &message_com;
		xQueueSendToBack(xCommandQueue, &pm_com, 0);

		// Subscribe message Butee_C
		message_sub.sem_id= &xSem1;
		message_sub.index = 4;
		message_sub.cb_evt= &call_back_event;
		// Send message to Subscribe Queue
		pm_sub = &message_sub;
		xQueueSendToBack(xSubscribeQueue, &pm_sub, 0);
		// Wait for Semaphore endlessly
		xSemaphoreTake(xSem1, portMAX_DELAY);

		// Actuator message Blocage_Palettiseur
		message_com.act_cmd = Blocage_Palettiseur;
		message_com.act_msk = Blocage_Palettiseur;
		pm_com = &message_com;
		xQueueSendToBack(xCommandQueue, &pm_com, 0);

		/*-----------------------------------------------------------*/

		// Actuator message Poussoir
		message_com.act_cmd = Poussoir;
		message_com.act_msk = Poussoir;
		pm_com = &message_com;
		xQueueSendToBack(xCommandQueue, &pm_com, 0);

		// Subscribe message Limite poussoir et NOT Butée
		message_sub.sem_id= &xSem1;
		message_sub.index = 5;
		message_sub.cb_evt= &call_back_event;
		// Send message to Subscribe Queue
		pm_sub = &message_sub;
		xQueueSendToBack(xSubscribeQueue, &pm_sub, 0);
		// Wait for Semaphore endlessly
		xSemaphoreTake(xSem1, portMAX_DELAY);

		// Actuator message Poussoir
		message_com.act_cmd = Actuator_Off;
		message_com.act_msk = Poussoir;
		pm_com = &message_com;
		xQueueSendToBack(xCommandQueue, &pm_com, 0);

		// Subscribe message Limite poussoir et NOT Butée
		message_sub.sem_id= &xSem1;
		message_sub.index = 5;
		message_sub.cb_evt= &call_back_event;
		// Send message to Subscribe Queue
		pm_sub = &message_sub;
		xQueueSendToBack(xSubscribeQueue, &pm_sub, 0);
		// Wait for Semaphore endlessly
		xSemaphoreTake(xSem1, portMAX_DELAY);

		// Compteur x3
		if (cnt == 2)
		{
			// Give the Event Group BIT1
			xEventGroupSetBits(myEventGroup, BIT1);

			// Wait the synchro
			xSemaphoreTake(xTask2_to_Task1, portMAX_DELAY);

			// Reset the compteur
			cnt = 0;
		}
		else
		{
			// Increment the compteur
			cnt ++ ;
		}

	}
}

/*
 *	Task_2
 */
void vTask2 (void *pvParameters)
{
	message_t 	message_sub;
	message_t	*pm_sub;
	command_message_t 	message_com;
	command_message_t	*pm_com;

	// Take the semaphore once to make sure it is empty
	xSemaphoreTake(xSem2, 0);

	// Initialization
	message_com.act_cmd = 0;
	message_com.act_msk= 0;

	// Wait 100ms for debug
	vTaskDelay(10);

	while(1)
	{
		// Wait for synchro
		xSemaphoreTake(xTask3_to_Task2, portMAX_DELAY);

		// Actuator message Monter ascenseur
		message_com.act_cmd = Monter_asc | Asc_to_limit;
		message_com.act_msk = Monter_asc | Asc_to_limit;
		pm_com = &message_com;
		xQueueSendToBack(xCommandQueue, &pm_com, 0);

		// Subscribe message Etage 1
		message_sub.sem_id= &xSem2;
		message_sub.index = 6;
		message_sub.cb_evt= &call_back_event;
		// Send message to Subscribe Queue
		pm_sub = &message_sub;
		xQueueSendToBack(xSubscribeQueue, &pm_sub, 0);
		// Wait for Semaphore endlessly
		xSemaphoreTake(xSem2, portMAX_DELAY);

		// Actuator message STOP ascenseur
		message_com.act_cmd = Actuator_Off;
		message_com.act_msk = Monter_asc | Asc_to_limit;
		pm_com = &message_com;
		xQueueSendToBack(xCommandQueue, &pm_com, 0);

		/*-----------------------------------------------------------*/

		// Give the synchro
		xSemaphoreGive(xTask2_to_Task1);

		// Give the Event Group BIT0
		xEventGroupSetBits(myEventGroup, BIT0);

		// Wait for the synchro
		xSemaphoreTake(xTask4_to_Task2, portMAX_DELAY);

		// Actuator message Descendre_asc
		message_com.act_cmd = Descendre_asc ;
		message_com.act_msk = Descendre_asc ;
		pm_com = &message_com;
		xQueueSendToBack(xCommandQueue, &pm_com, 0);

		// Subscribe message Etage 2
		message_sub.sem_id= &xSem2;
		message_sub.index = 7;
		message_sub.cb_evt= &call_back_event;
		// Send message to Subscribe Queue
		pm_sub = &message_sub;
		xQueueSendToBack(xSubscribeQueue, &pm_sub, 0);
		// Wait for Semaphore endlessly
		xSemaphoreTake(xSem2, portMAX_DELAY);

		// Actuator message Descendre_asc
		message_com.act_cmd = Actuator_Off ;
		message_com.act_msk = Descendre_asc ;
		pm_com = &message_com;
		xQueueSendToBack(xCommandQueue, &pm_com, 0);

		/*-----------------------------------------------------------*/

		// Give the synchro
		xSemaphoreGive(xTask2_to_Task1);

		// Give the Event Group BIT0
		xEventGroupSetBits(myEventGroup, BIT0);

		// Wait for the synchro
		xSemaphoreTake(xTask4_to_Task2, portMAX_DELAY);

		// Actuator message Descendre_asc
		message_com.act_cmd = Descendre_asc | Asc_to_limit;
		message_com.act_msk = Descendre_asc | Asc_to_limit;
		pm_com = &message_com;
		xQueueSendToBack(xCommandQueue, &pm_com, 0);

		// Subscribe message Etage RDC
		message_sub.sem_id= &xSem2;
		message_sub.index = 8;
		message_sub.cb_evt= &call_back_event;
		// Send message to Subscribe Queue
		pm_sub = &message_sub;
		xQueueSendToBack(xSubscribeQueue, &pm_sub, 0);
		// Wait for Semaphore endlessly
		xSemaphoreTake(xSem2, portMAX_DELAY);

		// Actuator message Descendre_asc
		message_com.act_cmd = Actuator_Off;
		message_com.act_msk = Descendre_asc | Asc_to_limit;
		pm_com = &message_com;
		xQueueSendToBack(xCommandQueue, &pm_com, 0);

		// Give the synchro
		xSemaphoreGive(xTask2_to_Task3);

	}
}

/*
 *	Task_3
 */
void vTask3 (void *pvParameters)
{
	message_t 	message_sub;
	message_t	*pm_sub;
	command_message_t 	message_com;
	command_message_t	*pm_com;

	// Take the semaphore once to make sure it is empty
	xSemaphoreTake(xSem3, 0);

	// Initialization
	message_com.act_cmd = 0;
	message_com.act_msk= 0;

	// Wait 100ms for debug
	vTaskDelay(10);

	while(1)
	{
		// Actuator message Distrib Palette
		message_com.act_cmd = Distrib_P;
		message_com.act_msk = Distrib_P;
		pm_com = &message_com;
		xQueueSendToBack(xCommandQueue, &pm_com, 0);

		//--------------Send only one pallet-------------//
		vTaskDelay(200);

		// Actuator message STOP Distrib Palette
		message_com.act_cmd = Actuator_Off;
		message_com.act_msk = Distrib_P;
		pm_com = &message_com;
		xQueueSendToBack(xCommandQueue, &pm_com, 0);

		// Subscribe message Entree_Palletiseur
		message_sub.sem_id= &xSem3;
		message_sub.index = 15;
		message_sub.cb_evt= &call_back_event;
		// Send message to Subscribe Queue
		pm_sub = &message_sub;
		xQueueSendToBack(xSubscribeQueue, &pm_sub, 0);
		// Wait for Semaphore endlessly
		xSemaphoreTake(xSem3, portMAX_DELAY);

		// Actuator message Distrib Palette
		message_com.act_cmd = Actuator_Off;
		message_com.act_msk = Distrib_P;
		pm_com = &message_com;
		xQueueSendToBack(xCommandQueue, &pm_com, 0);

		/*-----------------------------------------------------------*/

		// Actuator message Charger_Palette
		message_com.act_cmd = Charger_P;
		message_com.act_msk = Charger_P;
		pm_com = &message_com;
		xQueueSendToBack(xCommandQueue, &pm_com, 0);

		// Subscribe message Sortie palette
		message_sub.sem_id= &xSem3;
		message_sub.index = 9;
		message_sub.cb_evt= &call_back_event;
		// Send message to Subscribe Queue
		pm_sub = &message_sub;
		xQueueSendToBack(xSubscribeQueue, &pm_sub, 0);
		// Wait for Semaphore endlessly
		xSemaphoreTake(xSem3, portMAX_DELAY);

		// Actuator message Charger_Palette
		message_com.act_cmd = Actuator_Off;
		message_com.act_msk = Charger_P;
		pm_com = &message_com;
		xQueueSendToBack(xCommandQueue, &pm_com, 0);

		// Give the synchro
		xSemaphoreGive(xTask3_to_Task2);

		/*-----------------------------------------------------------*/

		// Wait for synchro
		xSemaphoreTake(xTask2_to_Task3, portMAX_DELAY);

		// Actuator message Charger_Palette
		message_com.act_cmd = Charger_P;
		message_com.act_msk = Charger_P;
		pm_com = &message_com;
		xQueueSendToBack(xCommandQueue, &pm_com, 0);

		// Subscribe message NOT Sortie palette
		message_sub.sem_id= &xSem3;
		message_sub.index = 10;
		message_sub.cb_evt= &call_back_event;
		// Send message to Subscribe Queue
		pm_sub = &message_sub;
		xQueueSendToBack(xSubscribeQueue, &pm_sub, 0);
		// Wait for Semaphore endlessly
		xSemaphoreTake(xSem3, portMAX_DELAY);

		// Actuator message Charger_Palette
		message_com.act_cmd = Actuator_Off;
		message_com.act_msk = Charger_P;
		pm_com = &message_com;
		xQueueSendToBack(xCommandQueue, &pm_com, 0);
	}
}

/*
 *	Task_4
 */
void vTask4 (void *pvParameters)
{
	message_t 	message_sub;
	message_t	*pm_sub;
	command_message_t 	message_com;
	command_message_t	*pm_com;

	// Take the semaphore once to make sure it is empty
	xSemaphoreTake(xSem4, 0);

	// Initialization
	message_com.act_cmd = 0;
	message_com.act_msk= 0;

	// Wait 100ms for debug
	vTaskDelay(10);

	while(1)
	{
		// Wait for Event Group
		xEventGroupWaitBits(myEventGroup, (BIT0 | BIT1), pdTRUE, pdTRUE, portMAX_DELAY);

		// Actuator message Clamp
		message_com.act_cmd = Clamp;
		message_com.act_msk = Clamp;
		pm_com = &message_com;
		xQueueSendToBack(xCommandQueue, &pm_com, 0);

		// Subscribe message Clamped
		message_sub.sem_id= &xSem4;
		message_sub.index = 12;
		message_sub.cb_evt= &call_back_event;
		// Send message to Subscribe Queue
		pm_sub = &message_sub;
		xQueueSendToBack(xSubscribeQueue, &pm_sub, 0);
		// Wait for Semaphore endlessly
		xSemaphoreTake(xSem4, portMAX_DELAY);

		/*-----------------------------------------------------------*/

		// Actuator message Porte
		message_com.act_cmd = Porte;
		message_com.act_msk = Porte;
		pm_com = &message_com;
		xQueueSendToBack(xCommandQueue, &pm_com, 0);

		// Subscribe message Porte ouverte
		message_sub.sem_id= &xSem4;
		message_sub.index = 11;
		message_sub.cb_evt= &call_back_event;
		// Send message to Subscribe Queue
		pm_sub = &message_sub;
		xQueueSendToBack(xSubscribeQueue, &pm_sub, 0);
		// Wait for Semaphore endlessly
		xSemaphoreTake(xSem4, portMAX_DELAY);

		/*-----------------------------------------------------------*/

		// Actuator message Declamp
		message_com.act_cmd = Actuator_Off;
		message_com.act_msk = Clamp;
		pm_com = &message_com;
		xQueueSendToBack(xCommandQueue, &pm_com, 0);

		// Subscribe message Declamped
		message_sub.sem_id= &xSem4;
		message_sub.index = 13;
		message_sub.cb_evt= &call_back_event;
		// Send message to Subscribe Queue
		pm_sub = &message_sub;
		xQueueSendToBack(xSubscribeQueue, &pm_sub, 0);
		// Wait for Semaphore endlessly
		xSemaphoreTake(xSem4, portMAX_DELAY);

		// Give the synchro
		xSemaphoreGive(xTask4_to_Task2);

		// Wait asc descendu
		vTaskDelay(100);

		// Actuator message Ferme Porte
		message_com.act_cmd = Actuator_Off;
		message_com.act_msk = Porte;
		pm_com = &message_com;
		xQueueSendToBack(xCommandQueue, &pm_com, 0);

		// Subscribe message Porte ouverte
		message_sub.sem_id= &xSem4;
		message_sub.index = 14;
		message_sub.cb_evt= &call_back_event;
		// Send message to Subscribe Queue
		pm_sub = &message_sub;
		xQueueSendToBack(xSubscribeQueue, &pm_sub, 0);
		// Wait for Semaphore endlessly
		xSemaphoreTake(xSem4, portMAX_DELAY);


	}
}

/*
 * Task_Pub
 */
void vTaskPub (void *pvParameters)
{
	message_t *message;
	message_t sub_tab[SUB_TAILLE];
	uint32_t sensor;
	uint8_t i, exist;

	for ( i = 0; i < SUB_TAILLE; i++)			// Initialize all sub NULL
	{
		sub_tab[i].sem_id = NULL;
		sub_tab[i].index = 0;
		sub_tab[i].cb_evt = NULL;
	}

	// Time manage
	portTickType	xLastWakeTime;

	// Initialize timing
	xLastWakeTime = xTaskGetTickCount();

	// Wait 100ms for debug
	vTaskDelay(10);

	while(1)
	{
		// Update sensors vector
		sensor = FACTORY_IO_Sensors_Get();

		//Flag initialization (doublon)
		exist = 0;

		// Get free heap size
		free_heap_size = xPortGetFreeHeapSize();

		// Wait for something in the message Queue
		if( xQueueReceive( xSubscribeQueue, &message, 0 ) == pdPASS )
		{
			for (i = 0; i < SUB_TAILLE; i++)
			{
				// Check doublon
				if (sub_tab[i].sem_id != message->sem_id ||
					 sub_tab[i].index != message->index)
				{
					if (sub_tab[i].sem_id == 0)
					{
						break;
					}
				}
				else
				{
					exist = 1;
					break;
				}

			}

			// Create new subscription
			if (exist == 0)
			{
				sub_tab[i].sem_id = message->sem_id;
				sub_tab[i].index = message->index;
				sub_tab[i].cb_evt = message->cb_evt;
			}

		}

		// Publish and update the sub table
		for (i = 0; i < SUB_TAILLE; i++)
		{
			// Check if there is a sub in this slot
			if (sub_tab[i].sem_id != NULL)
			{
				// If the event is true
				if (sub_tab[i].cb_evt(sub_tab[i].index,sensor) == 1 )
				{
					// Give the corresponding sem
					xSemaphoreGive(*(sub_tab[i].sem_id));

					// Delete corresponding subscription
					sub_tab[i].sem_id = NULL;
					sub_tab[i].index = 0;
					sub_tab[i].cb_evt = NULL;
				}
			}
		}

		// Wait for 100ms since last wakeup
		vTaskDelayUntil(&xLastWakeTime, (10/portTICK_RATE_MS));
	}
}

/*
 * Task_Write
 */
void vTask_Write (void *pvParameters)
{
	uint8_t trame[LENGHT];
	uint32_t cmd = 0;
	uint32_t *pcmd;

	command_message_t *message;
	uint8_t n= 0;

	// Set priority level 2 for DMA1_Channel5 interrupts
	NVIC_SetPriority(DMA1_Channel4_5_6_7_IRQn, configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY + 1);

	// Enable DMA1_Channel5 interrupts
	NVIC_EnableIRQ(DMA1_Channel4_5_6_7_IRQn);

	// Wait 100ms for debug
	vTaskDelay(10);

	while(1)
	{
		// Wait for something in the message Queue
		xQueueReceive(xCommandQueue, &message, portMAX_DELAY);

		// Actualize actuators
		pcmd = &cmd;
		FACTORY_IO_Actuators_Set(*message, pcmd, trame);

		// Flag initialization
		n = 0;

		// Copy message in the DMA buffer
		if ((trame)[0] == 0xAD)
		{
			for (n=0; n < 7; n++)
			{
				tx_dma_buffer[n] = (trame)[n];

			}
		}
		// DEBUG message
		else
		{
			while((trame)[n] != '\n')
			{
				tx_dma_buffer[n] = (trame)[n];
				n++ ;
			}
		}


		// Set Memory Buffer size
		DMA1_Channel4->CNDTR = n;

		// Enable DMA1 Channel 4
		DMA1_Channel4->CCR |= DMA_CCR_EN;

		// Enable USART2 DMA Request on TX
		USART2->CR3 |= USART_CR3_DMAT;

		// Wait for Semaphore endlessly
		xSemaphoreTake(xSem_DMA_TC, portMAX_DELAY);

		// Disable DMA1 Channel 4
		DMA1_Channel4->CCR &= ~DMA_CCR_EN;

		// Disable USART2 DMA Request on TX
		USART2->CR3 &= ~USART_CR3_DMAT;

		// Wait 100ms for to avoid overwriting
		vTaskDelay(10);
	}
}

/*
 * 	Clock configuration for the Nucleo STM32F072RB board
 * 	HSE input Bypass Mode 			-> 8MHz
 * 	SYSCLK, AHB, APB1 				-> 48MHz
 *
 *  PA8 as MCO with /16 prescaler 	-> 3MHz
 *
 *  Vico Latorre - 05/08/2017
 */

static void SystemClock_Config()
{
	uint32_t	HSE_Status;
	uint32_t	PLL_Status;
	uint32_t	SW_Status;
	uint32_t	timeout = 0;

	timeout = 1000000;

	// Start HSE in Bypass Mode
	RCC->CR |= RCC_CR_HSEBYP;
	RCC->CR |= RCC_CR_HSEON;

	// Wait until HSE is ready
	do
	{
		HSE_Status = RCC->CR & RCC_CR_HSERDY_Msk;
		timeout--;
	} while ((HSE_Status == 0) && (timeout > 0));

	// Select HSE as PLL input source
	RCC->CFGR &= ~RCC_CFGR_PLLSRC_Msk;
	RCC->CFGR |= (0x02 <<RCC_CFGR_PLLSRC_Pos);

	// Set PLL PREDIV to /1
	RCC->CFGR2 = 0x00000000;

	// Set PLL MUL to x6
	RCC->CFGR &= ~RCC_CFGR_PLLMUL_Msk;
	RCC->CFGR |= (0x04 <<RCC_CFGR_PLLMUL_Pos);

	// Enable the main PLL
	RCC-> CR |= RCC_CR_PLLON;

	// Wait until PLL is ready
	do
	{
		PLL_Status = RCC->CR & RCC_CR_PLLRDY_Msk;
		timeout--;
	} while ((PLL_Status == 0) && (timeout > 0));

        // Set AHB prescaler to /1
	RCC->CFGR &= ~RCC_CFGR_HPRE_Msk;
	RCC->CFGR |= RCC_CFGR_HPRE_DIV1;

	//Set APB1 prescaler to /1
	RCC->CFGR &= ~RCC_CFGR_PPRE_Msk;
	RCC->CFGR |= RCC_CFGR_PPRE_DIV1;

	// Enable FLASH Prefetch Buffer and set Flash Latency
	FLASH->ACR = FLASH_ACR_PRFTBE | FLASH_ACR_LATENCY;

	/* --- Until this point, MCU was still clocked by HSI at 8MHz ---*/
	/* --- Switching to PLL at 48MHz Now!  Fasten your seat belt! ---*/

	// Select the main PLL as system clock source
	RCC->CFGR &= ~RCC_CFGR_SW;
	RCC->CFGR |= RCC_CFGR_SW_PLL;

	// Wait until PLL becomes main switch input
	do
	{
		SW_Status = (RCC->CFGR & RCC_CFGR_SWS_Msk);
		timeout--;
	} while ((SW_Status != RCC_CFGR_SWS_PLL) && (timeout > 0));

	/* --- Here we go! ---*/

	/*--- Use PA8 as MCO output at 48/16 = 3MHz ---*/

	// Set MCO source as SYSCLK (48MHz)
	RCC->CFGR &= ~RCC_CFGR_MCO_Msk;
	RCC->CFGR |=  RCC_CFGR_MCOSEL_SYSCLK;

	// Set MCO prescaler to /16 -> 3MHz
	RCC->CFGR &= ~RCC_CFGR_MCOPRE_Msk;
	RCC->CFGR |=  RCC_CFGR_MCOPRE_DIV16;

	// Enable GPIOA clock
	RCC->AHBENR |= RCC_AHBENR_GPIOAEN;

	// Configure PA8 as Alternate function
	GPIOA->MODER &= ~GPIO_MODER_MODER8_Msk;
	GPIOA->MODER |= (0x02 <<GPIO_MODER_MODER8_Pos);

	// Set to AF0 (MCO output)
	GPIOA->AFR[1] &= ~(0x0000000F);
	GPIOA->AFR[1] |=  (0x00000000);

	// Update SystemCoreClock global variable
	SystemCoreClockUpdate();
}

void vApplicationIdleHook()
{
	// Set sleep mode here
	__WFI();
}
