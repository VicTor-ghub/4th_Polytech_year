/*
 * event.c
 *
 *  Created on: 4 janv. 2022
 *      Author: victor.rios
 */

#include "event.h"
#include "main.h"

uint8_t call_back_event(uint8_t indice, uint32_t sensor)
{
	switch (indice)
	{
	// TASK 1
	case 0:	// NOT Carton envoyé
		if ((sensor & Carton_envoye))
		{
			return 0;
		}
		else return 1;
	case 1: // Carton envoyé
		if ((sensor & Carton_envoye))
		{
			return 1;
		}
		else return 0;
	case 2: // Entrée palletiseur
		if ((sensor & Entree_Palletiseur))
		{
			return 0;
		}
		else return 1;
	case 3: // NOT Entrée palletiseur
		if ((sensor & Entree_Palletiseur))
		{
			return 1;
		}
		else return 0;
	case 4: // Butée
		if ((sensor & Butee_C))
		{
			return 1;
		}
		else return 0;
	case 5: // Limite poussoir et NOT Butée
		if ((sensor & Limite_poussoir) && !(sensor & Butee_C))
		{
			return 1;
		}
		else return 0;

	// TASK 2
	case 6: // Etage 1
		if ((sensor & Asc_etage_1))
		{
			return 1;
		}
		else return 0;
	case 7: // Etage 1 complet
		if ((sensor & Asc_etage_2) && !(sensor & Asc_etage_1) && !(sensor & Asc_en_mvt))
		{
			return 1;
		}
		else return 0;
	case 8: // Etage 2 complet
		if ((sensor & Asc_etage_rdc) && !(sensor & Asc_en_mvt))
		{
			return 1;
		}
		else return 0;

	// TASK 3
	case 9: // Sortie palette
		if ((sensor & Sortie_P))
		{
			return 1;
		}
		else return 0;
	case 10: // NOT Sortie palette
		if ((sensor & Sortie_P))
		{
			return 0;
		}
		else return 1;
	case 15: // Entree_Palette
		if ((sensor & Entree_P))
		{
			return 1;
		}
		else return 0;


	// TASK 4
	case 11: // Porte ouverte
		if ((sensor & Porte_ouverte) && (sensor & Limite_porte))
		{
			return 1;
		}
		else return 0;
	case 12: // Clamped
		if ((sensor & Clamped))
		{
			return 1;
		}
		else return 0;
	case 13: // Declamped
		if ((sensor & Clamped))
		{
			return 0;
		}
		else return 1;
	case 14: // NOT Porte ouverte
		if ((sensor & Porte_ouverte) && (sensor & Limite_porte))
		{
			return 0;
		}
		else return 1;
}

	return 0;
}
