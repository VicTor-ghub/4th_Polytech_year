-- Exemple 1. Calculer la population mondiale. 

select sum(population) as 'pop_mondiale' from bbc;

-- Exercice 1. Calculez le PIB total de la région Europe, en milliards de dollars

select sum(gdp)/1e9 as 'PIB(milliards)'
from bbc
where region = 'Europe';

-- Exemple 2. Combien de pays ont une surface d’au moins un million
-- de km2 ? 

select count(*) from bbc
where area > 1e6;

-- Exemple 3. Quelle est la population totale des pays de l’Asie-Pacifique (en millions d’habitants)

select round(sum(population)/1e6,2) as 'pop_totale' 
from bbc
where region = 'Asia-Pacific';

-- Exercice 2 : Calculez la moyenne des PIB/habitant des pays d’Europe ? Arrondissez à l’unité. 

select round(avg(gdp/population),0) as 'moyenne_PIB/hab'
from bbc
where region = 'Europe';

-- Exercice 3 : Calculez le PIB/habitant de la région Europe ? 

select round(sum(gdp)/sum(population)) as 'PIB/hab'
from bbc
where region = 'Europe' and gdp is not null;

-- Exercice 4 : Première tentative : Listez les pays d’Europe dont le PIB/habitant 
-- est inférieur de 70% à celui de la région Europe

select name, round(gdp/population) as 'PIB/hab'
from bbc
where region ='Europe' and (gdp/population) < 16348*0.3;

-- Exercice 5 : Calculez le nombre des pays d’Amérique Centrale 
-- et leur population moyenne (en millions d’habitants, à 3 décimales). 

select region, count(population) as 'nb_pays' , round(avg(population)/1e6,3) as 'pop_moyenne(millions)'
from bbc
where region = 'Central America';

-- Exemple 4 : Montrer le nom de toutes les régions en une seule ligne

SELECT group_concat(DISTINCT region) FROM bbc; 

-- Exercice 6 : Montrez les noms de tous les pays d’Amérique du Sud. 

SELECT group_concat(name order by population desc ,' ') as 'Pays sud américains (par pop desc)'
FROM bbc
where region = 'South America';