-- Exemple 1 : Montrer l’année, le score, le titre et le nom du directeur de
-- tous les films produits entre 1980 et 1985 ayant obtenu un score
-- supérieur à 8, classés par année, score décroissant, titre.

select m.yr, m.score, m.title, a.name
from movies m 
	join actors a on m.director = a.id
where m.yr between 1980 and 1985 and m.score > 8
order by m.yr, m.score desc, m.title;

-- Exercice 1 : Montrez l’année, le nom du directeur et le titre de tous les films produits
-- de 1990 à 1995 dont le directeur se prénomme David, classés par année, puis par
-- nom de directeur, puis par titre.

SELECT 
    m.yr, a.name, m.title
FROM
    movies m
        JOIN
    actors a ON m.director = a.id
WHERE
    m.yr BETWEEN 1990 AND 1995
        AND a.name like 'David%'
ORDER BY m.yr , a.name , m.title;

-- Exemple 2 : Montrer les titres de tous les films des années 1995-1999
-- dans lesquels a joué Bruce Willis, avec l'année et le numéro de rôle,
-- classés par année, puis par numéro de rôle.

select a.name, m.yr, c.ord, m.title
from actors a 
	join castings c on c.actorid = a.id
    join movies m on m.id = c.movieid
where a.name ='Bruce Willis' and m.yr between 1995 and 1999
order by m.yr, c.ord;

-- Exercice 2 : Montrer les noms de tous les acteurs qui ont tenu un premier rôle dans
-- un ou plusieurs des films de l’année 1999, de score supérieur ou égal à 8. Affichez
-- aussi le titre et le score de ces films. Classez par score décroissant, puis par nom
-- d’acteur.

select m.score, a.name,  m.title
from actors a 
	join castings c on c.actorid = a.id
    join movies m on m.id = c.movieid
where m.score >= 8 and m.yr = 1999 and c.ord = 1
order by  m.score desc, a.name;

-- Exemple 3 : Montrer les noms de tous les acteurs qui ont joué dans au
-- moins 15 films pendant la décennie 1990-1999, avec le nombre de rôles
-- tenus (triés par nombre de rôles décroissant, puis par nom).

select count(castings.actorid) as nbr_role, name as acteur
from actors
 join castings on actors.id = castings.actorid
 join movies on movies.id = castings.movieid
where yr between 1990 and 1999
group by actors.id
having nbr_role >= 15
order by nbr_role desc, name;

-- Exercice 3 : Montrez les noms des directeurs d’au moins 6 films de la décennie 1980-
-- 1989. Indiquez le nombre de films dirigés. Triez par nombre de films décroissant, puis
-- par nom.

select count(director) as nbr_dir, a.name as dir 
from movies m 
	join actors a on m.director = a.id
where yr between 1980 and 1989
group by director
having nbr_dir >= 6
order by nbr_dir desc, name;

-- Exemple 4. Self-Join. Remake : y a-t-il deux films ayant le même titre ?
-- Montrez chaque film et ses homonymes, le plus ancien en premier.

select m1.yr, m1.title, m2.yr, m2.title
from movies m1
 join movies m2 on m1.title=m2.title
where m1.yr < m2.yr or (m1.yr=m2.yr and m1.id<m2.id)
order by m1.title;

-- Exemple 5 : Montrer tous les acteurs du film « Star Wars », classés par
-- numéro de rôle.

select name, ord
from actors
 join castings on actors.id = castings.actorid
where castings.movieid = (select id from movies where title = 'Star Wars')
order by ord;

select c.ord, a.name
from actors a
 join castings c on c.actorid = a.id
 join movies m on m.id = c.movieid
where m.title = 'Star Wars'
order by c.ord;

-- Exercice 4 : Quelle est la proportion des directeurs qui sont aussi des acteurs ?

select count(director) as nbr_dir 
	from movies m 
	join actors a on m.director = a.id
