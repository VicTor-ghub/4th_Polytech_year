-- Exemple 1 : Montrer toutes les lignes de la table « bbc »

select * from bbc;

-- Exemple 2 : Quel est le nombre des lignes de la table ?

select count(*) from bbc;

-- Exemple 3 : Limiter le nombre de lignes de résultats d’une requête

SELECT * FROM bbc LIMIT 6;

-- Exemple 4 : Quelle est la surface de Malte ?

SELECT name, area FROM bbc
WHERE name = 'Malta'; 

-- Exercice 1 : Quelle est la population de la France ?

select name, population from bbc
where name = 'France';

-- Exemple 5 : Montrer toutes les régions, sans répétition

SELECT DISTINCT region FROM bbc;

-- Exemple 6 : Montrer le nom, la population (en millions) et le PIB par
-- habitant pour tous les pays de plus de 150 millions d’habitants.

select name, (population/1000000) as 'pop/mil', (gdp/population) as 'PIB/hab'
from bbc
where population > 150000000; 

-- Exercice 2 : Petits pays riches : En utilisant l’opérateur logique « and »,
-- montrez le nom, la population, la surface et le PIB par habitant de tous
-- les pays de surface inférieure à 10000 km2, et de PIB supérieur à 500
-- millions de $.

select name, population, area, gdp/population as 'PIB/hab' 
from bbc 
where area < 10000 and gdp > 500000000;

-- Exemple 7 : Montrer le nom, la population et le PIB des pays baltes :
-- Estonie (Estonia), Lettonie (Latvia) et Lituanie (Lithuania).

select name, population, gdp 
from bbc
where name in ('Estonia' ,'Latvia', 'Lithuania');

-- Exercice 3 : Montrez le nom, la population et le PIB/habitant des pays
-- scandinaves 

select name, population, gdp/population as 'PIB/hab'
from bbc
where name in ('Denmark' ,'Finland', 'Iceland','Norway','Sweden');

-- Exemple 8 : Quels noms de pays commencent par « F » ?

select name
from bbc
where name like 'F%';

-- Exercice 4 : Montrez les pays dont le nom contient « Republic »

select name
from bbc
where name like '%Republic%';

-- Exercice 5 : Montrez les pays dont le nom contient « Republic », mais ni
-- au début, ni à la fin.

select name
from bbc
where name like '%Republic%'
	and not name like'Republic%' 
    and not name like'%Republic';
    
-- Exemple 9 : Montrer les pays dont la surface est comprise entre
-- deux limites.

select name, area/1000 as 'surface(milliers)' 
from bbc
where area between 200e3 and 250e3;

-- Exercice 6 : Montrez les pays de la région « Europe » dont la densité de
-- population est comprise entre 100 et 120 habitants / km2.

select name, population/area as 'hab/km2'
from bbc
where region ='Europe' and (population/area between 100 and 120);

-- Exemple 10 : Classement : Quels sont les 10 plus grands pays du
-- monde (en surface) ?

select name, area/1000 
from bbc 
order by area desc
limit 10;

-- Exercice 7 : Montrez les pays de plus de 100 millions d’habitants avec
-- leur population et leur région, classés par région, et pour chaque région
-- par nombre d’habitants décroissant.

select region, name, population/1e6 as 'pop(mil)'
from bbc
where population > 100e6
order by region, population desc;

-- Exemple 11 : Fusionner des champs pour avoir moins de colonnes et
-- adapter la présentation. Utiliser le format avec les parenthèses :
-- « pays (région) | population ».

select concat(name,'(', region, ')') AS 'name (region)', population
from bbc
limit 10;