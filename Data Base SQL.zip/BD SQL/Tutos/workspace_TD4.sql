-- Exemple 1 : Quels sont tous les pays de la même région que l’Inde ?

SELECT region FROM bbc
WHERE name = 'India';

SELECT group_concat(name) FROM bbc
WHERE region = 'South Asia';

SELECT group_concat(name) FROM bbc
WHERE region = (SELECT region FROM bbc WHERE name = 'India');

-- Exercice 1. Quels sont les pays d’Europe dont la surface est supérieure ou égale
-- à celle de la France ? Indiquez la surface en milliers de km2.

select name, area/1000 as surface
from bbc
where area >= (select area from bbc where name = 'France') and region = 'Europe';

-- Exemple 2. Quelle est la densité de population des 5 plus vastes
-- pays du monde ? Classez les pays par densité décroissante.

select name, area,(population/area) as densite
from bbc
order by area desc
limit 5;

select * from (select name, area, population/area as density from bbc
 order by area desc limit 5) t2
order by t2.density desc; 

-- Exercice 2 : Quels sont les pays hors d'Europe plus riches que l'Europe 
-- (la richesse étant mesurée en PIB/habitant) ? Classez-les.

select  sum(gdp/population) as PIB_par_hab
from bbc 
where region = 'Europe';

select  name, round(gdp/population) as PIB_par_hab
from bbc
where region != 'Europe' and (gdp/population) > (select  sum(gdp)/sum(population) as PIB_par_hab
from bbc where region = 'Europe' and gdp is not null)
order by PIB_par_hab desc;

-- Exercice 3 : Quelle est la part de chaque pays européens dans le PIB européen
-- total ? Classez les pays par contribution décroissante.

select name as 'Pays', round(gdp/(select sum(gdp) from bbc where region = 'Europe')*100,2)
 as 'Pourcent' from bbc
 where region = 'Europe'
 order by Pourcent desc;
 
 -- Exemple 3 : Recherchez les pays dont le PIB/Habitant est trois fois
-- plus élevé que celui de leur région. Affichez leur région, leur nom et
-- leur PIB/Habitant, classés par région, puis par PIB/Habitant décroissant.

select region, round(sum(gdp)/sum(population),4) as PIB_P
from bbc
group by region;

select region, name as pays, gdp/population as PIBpH from bbc
where region = 'Europe'
and gdp/population >= 3.0*(select sum(gdp)/sum(population) from bbc
 where region = 'Europe');

select bbc1.region, bbc1.name as pays, bbc1.gdp/bbc1.population as PIBpH
from bbc as bbc1
where bbc1.gdp/bbc1.population >= 3*(select sum(bbc2.gdp)/sum(bbc2.population)
 from bbc as bbc2
 where bbc2.region = bbc1.region)
order by bbc1.region, PIBpH desc;

select region, name as pays, gdp/population as PIBpH from bbc as bbc1
where gdp/population >= 3*(select sum(gdp)/sum(population) from bbc as bbc2
where region = bbc1.region)
order by region, PIBpH desc;

-- Exercice 4 : Quel est le plus grand pays de chaque région ? Afficher son nom, sa
-- région et sa surface.

select name, region, area from bbc
where region = 'Europe'
order by area desc
limit 1;

select bbc1.name, bbc1.region, bbc1.area from bbc as bbc1
where bbc1.area = ( select max(bbc2.area) from bbc as bbc2
	where bbc2.region = bbc1.region);

-- Exercice 5 : Quels sont les pays du monde plus vastes 
-- que la somme des surfaces de tous les autres pays de leur région ?

select bbc1.region, bbc1.name, bbc1.area
from bbc as bbc1
where bbc1.area > ( select sum(bbc2.area)-max(bbc2.area) from bbc as bbc2
	where bbc2.region = bbc1.region);
    
-- Exercice 6 : Donner pour chaque pays, sa région, son nom, sa surface,
-- la surface de sa région, et la part de ce pays dans la surface de sa région.

select region, name, area, 
	(select sum(bbc2.area) from bbc as bbc2 where bbc1.region = bbc2.region) as region_area,
    (select (bbc2.area/region_area)*100 from bbc as bbc2 where bbc1.name = bbc2.name) as percent_from_region
from bbc as bbc1
order by region, percent_from_region desc;

select
 b1.region,
 b1.name,
 b1.area,
 (select sum(area) from bbc b2 where b2.region = b1.region) as region_area,
 100*area/(select sum(area) from bbc b2 where b2.region = b1.region)
 as percent_region_area
from bbc b1
order by b1.region, percent_region_area desc;