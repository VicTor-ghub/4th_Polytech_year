-- Exemple 1 : Montrer le nombre de pays de chaque région.

SELECT region, COUNT(name) as nb_pays FROM bbc
GROUP BY region;

-- Exercice 1. Calculez les PIB total de chaque région, en milliards de dollars, classés par valeurs décroissantes. 

select region, sum(gdp)/1e9 as 'PIB/hab' 
from bbc
group by region
order by sum(gdp)/1e9 desc;

-- Exemple 2 : Montrer pour chaque région, le nombre de pays ayant
-- un PIB par habitant supérieur à 10 000.

select region, count(name)
from bbc
where gdp/population > 10000
group by region;

-- Exercice 2 : Donnez un tableau du nombre de pays par tranche de 5000$ de
-- PIB/Habitant.

select round(gdp/population)div 5000 + 1 as 'tranche',
	count(name) as 'nb_pays'
from bbc
group by tranche
order by tranche desc;

-- Exemple 3 : Montrer (seulement) les régions du monde dont le PIB/
-- habitant est supérieur à 10 000.

select region, round(sum(gdp)/sum(population)) as 'PIB_hab'
from bbc
where gdp is not null
group by region
having PIB_hab > 10000;

-- Exercice 3 : Avec une première requête, calculez la densité de population
-- mondiale. Utilisant la valeur numérique du résultat, montrez les régions de
-- densité supérieure à la moyenne mondiale, classées par densité décroissante.

select sum(population)/sum(area) as densité_mondiale from bbc;

select region, sum(population)/sum(area) as densité
from bbc
group by region
having densité > 48.1203
order by densité desc;

-- Exercice 4 : Ecrivez une commande produisant le même résultat que la commande suivante,
-- mais sans utilisez le mot clé « distinct ».

SELECT DISTINCT region FROM bbc ORDER BY region;

select region 
from bbc
group by region
order by region;
