-- Exemple 1 : Montrer l’année, le score, le titre et le nom du directeur de
-- tous les films produits entre 1980 et 1985 ayant obtenu un score
-- supérieur à 8, classés par année, score décroissant, titre.

select m.yr, m.score, m.title, a.name
from movies m join actors a on a.id = m.director
where yr between 1980 and 1985 and score > 8
order by yr, score desc, title;

-- Exercice 1 : Montrez l’année, le nom du directeur et le titre de tous les films produits
-- de 1990 à 1995 dont le directeur se prénomme David, classés par année, puis par
-- nom de directeur, puis par titre.

select m.yr, a.name as director_name, m.title
from movies m join actors a on a.id = m.director
where m.yr between 1990 and 1995 and a.name like 'David%'
order by m.yr, a.name, m.title;

-- Exemple 2 : Montrer les titres de tous les films des années 1995-1999
-- dans lesquels a joué Bruce Willis, avec l'année et le numéro de rôle,
-- classés par année, puis par numéro de rôle.

select m.title, m.yr, c.ord as num_role
from castings c 
	join movies m on m.id = c.movieid
    join actors a on a.id = c.actorid
where m.yr between 1995 and 1999 and a.name like 'Bruce Willis'
order by m.yr, c.ord;

-- Exercice 2 : Montrer les noms de tous les acteurs qui ont tenu un premier rôle dans
-- un ou plusieurs des films de l’année 1999, de score supérieur ou égal à 8. Affichez
-- aussi le titre et le score de ces films. Classez par score décroissant, puis par nom
-- d’acteur.

select a.name, m.title, m.score 
from castings c
	join movies m on m.id = c.movieid
    join actors a on a.id = c.actorid
where m.yr = 1999 and m.score >= 8 and c.ord = 1
order by m.score desc, a.name;

-- Exemple 3 : Montrer les noms de tous les acteurs qui ont joué dans au
-- moins 15 films pendant la décennie 1990-1999, avec le nombre de rôles
-- tenus (triés par nombre de rôles décroissant, puis par nom).

select a.name as acteur, count(c.actorid) as nb_role
from castings c
	join movies m on m.id = c.movieid
    join actors a on a.id = c.actorid
where m.yr between 1990 and 1999 
group by acteur
having nb_role >= 15
order by nb_role desc , acteur;

-- Exercice 3 : Montrez les noms des directeurs d’au moins 6 films de la décennie 1980-
-- 1989. Indiquez le nombre de films dirigés. Triez par nombre de films décroissant, puis
-- par nom.

select a.name, count(m.id) as nb_dir
from movies m
	join actors a on a.id = m.director
where m.yr between 1980 and 1989 
group by a.id
having nb_dir >= 6
order by  nb_dir desc,a.name;

-- Exemple 4. Self-Join. Remake : y a-t-il deux films ayant le même titre ?
-- Montrez chaque film et ses homonymes, le plus ancien en premier

select m1.yr, m2.yr, m1.title
from movies m1
 join movies m2 on m1.title=m2.title
where m1.yr < m2.yr or (m1.yr=m2.yr and m1.id<m2.id)
order by m1.title;

-- Exemple 5 : Montrer tous les acteurs du film « Star Wars », classés par
-- numéro de rôle.

select a.name, c.ord as num_role
from castings c
	join movies m on m.id = c.movieid
    join actors a on a.id = c.actorid
where m.title = 'Star Wars'
order by num_role;

-- Exercice 4 : Quelle est la proportion des directeurs qui sont aussi des acteurs ?

-- Nb_dir
select count(distinct m.director) as nb_act_dir
from movies m;

-- Nb_act_dir
select count(distinct m.director) as nb_act_dir
from actors a
	join movies m on a.id = m.director
	join castings c on a.id = c.actorid;
    
-- Nb_act_dir / Nb_dir (en %)
select 100*(select count(distinct a.id) from actors a
	join movies m on a.id = m.director
	join castings c on a.id = c.actorid ) /(select count(distinct director) from movies)
    as 'nb_dir_act/nb_dir %';

-- Exemple 6. Jointures multiples : Quels sont les acteurs qui ont joué avec
-- Charles Chaplin ? Quel année ? Dans quel film ? Classez par acteur, année, titre.

select a1.name, m.yr, m.title
from actors a1
	join castings c1 on c1.actorid = a1.id
    join movies m on m.id = c1.movieid
	join castings c2 on c2.movieid = m.id
	join actors a2 on a2.id = c2.actorid
where a2.name = 'Charles Chaplin' and a1.id != a2.id
order by a1.name, m.yr, m.title;

/*Exercice 5 : Quels sont les acteurs qui ont joué un rôle sous la direction du directeur
« Volker Schlondorff » ? Indiquez dans quel film et son année. Classez par nom, puis
par année.*/

select a1.name, m.yr, m.title
from actors a1
	join castings c on c.actorid = a1.id
    join movies m on m.id = c.movieid
	join actors a2 on m.director = a2.id
where a2.name = 'Volker Schlondorff' 
order by name, yr;

/*Exemple 7 : Left Join. Montrer l’année, le score, le titre et le nom du directeur de tous les films produits entre 1980 et 1985 ayant obtenu un
score supérieur à 8, classés par année, puis score décroissant, puis par titre.*/

select m.yr as année, m.score as score, coalesce(a.name, '*inconnu*') as directeur,
m.title as titre
from movies m
 left join actors a on a.id = m.director
where m.yr between 1980 and 1985 and m.score > 8.3
order by m.yr, m.score desc, m.title;

-- Bonus : les couples de films de même directeur en conservant ceux dont le directeur est inconnu (NULL)
select m.*, n.* from movies m
left join movies n on m.director = n.director
where n.id is null or m.id < n.id;

/*Exercice 6. Quelles sont dans la table des acteurs, [A] les personnes qui n’ont aucun
rôle connu ? [B] les personnes qui n’apparaissent comme réalisateur d’aucun film ? et
[C] les personnes sans rôle et sans direction de film ?*/

-- [A] Comptez le nombre de rôles de chaque personne, filtrez pour ne garder que celles qui n’ont aucun rôle
select a.name as no_actor, count(c.actorid) as nb_role
from actors a 
	left join castings c on a.id = c.actorid
group by a.id
having nb_role = 0;

-- [B] Comptez le nombre de directions de film de chaque personne, filtrez pour ne garder que celles qui n’en ont aucune.
select a.name as no_dir, count(m.director) as nb_dir
from actors a
	left join movies m on m.director =a.id
group by a.id
having nb_dir = 0;

-- Combinaison de [A] et [B]
select name as nom from actors
	left join movies on director = actors.id
	left join castings on actorid = actors.id
group by actors.id
having count(actorid) = 0 and count(director) = 0;

-- Avec select imbriqués
select name from actors
where id not in (select distinct coalesce(director, 0) from movies) and
 id not in (select distinct actorid from castings);
 
 -- Alternative
 select a.name from actors a
where (select count(m.id) from movies m where m.director=a.id) = 0
 and
 (select count(c.actorid) from castings c where c.actorid=a.id) = 0;