/*

a) Trouvez les lignes qui passent deux fois par un même arrêt, de position quelconque. 
Il s'agit donc des lignes qui font une boucle, qu'il s'agisse d'une ligne circulaire ou en forme de 8, de T, ou d'autres cas encore. Donnez le nom, leur longueur (lue dans buslines). 
classez dans l'ordre décroissant de la longueur de la ligne, puis par nom.

*/

select concat(b.company,b.number) as ligne,
	   b.nbr_stops

from buslines b
	join passages p1 on b.line_id=p1.lineid
	join passages p2 on b.line_id=p2.lineid

where p1.stopid = p2.stopid and p1.pos != p2.pos
group by concat(b.company,b.number)

order by b.nbr_stops desc, ligne;

/*

# ligne, nbr_stops

LRT32, 23

LRT52, 23

LRT12, 18

...

*/

-- 19 row(s) returned

/*

b) Quels sont les arrêts par lesquels une ligne quelconque passe au moins deux fois ? 
Faites un tableau de ces arrêts, avec le nom d'une ligne qui y passe deux fois, sa longueur (en nombre d'arrêts), la position du 1er passage et celle du 2ème passage. 
Classez par nom d'arrêt, puis par ligne.

*/

select s.name as arrêt,
	concat(b.company,b.number) as ligne,
    b.nbr_stops as longueur,    
    p1.pos as premier_passage,
    p2.pos as second_passage
    
from passages p1
	join passages p2 on p2.lineid = p1.lineid
	join buslines b on b.line_id=p1.lineid
	join stops s on s.stop_id=p1.stopid
where p1.stopid = p2.stopid and p1.pos < p2.pos

order by s.name, concat(b.company,b.number);

/*

# arrêt, ligne, longueur, premier_passage, second_passage

Boswall, LRT19, 10, 1, 10

Boswall, LRT19A, 7, 1, 7

Broomhouse, LRT12, 18, 8, 10

...

*/

-- 33 row(s) returned

/*

c) Faites un tableau plus synthétique indiquant pour chaque ligne le nombre des arrêts où elle passe plus d'une fois. 
Classez par en fonction de ce nombre (décroissant), puis par nom de ligne.

*/

select concat(b.company,b.number) as ligne,
    b.nbr_stops as longueur,    
    round(count(s.stop_id)/2) as nbDoublon
    
from passages p1
	join passages p2 on p2.lineid = p1.lineid
	join buslines b on b.line_id=p1.lineid
	join stops s on s.stop_id=p1.stopid
where p1.stopid = p2.stopid and p1.pos != p2.pos

group by concat(b.company,b.number)

order by nbDoublon desc, concat(b.company,b.number);

/*

# ligne, longueur, nbDoublon

LRT81, 12, 4

LRT81A, 13, 4

LRT12, 18, 3

*/

-- 19 row(s) returned

/*

d) Ajoutez pour chaque ligne la liste de ses points de rebouclage.

*/

select concat(b.company,b.number) as ligne,
    b.nbr_stops as longueur,    
    round(count(s1.stop_id)) as nbDoublon,
    group_concat(distinct s1.name order by p1.pos) as doublons,
    group_concat(distinct p1.pos) as pos_doublons
    
from passages p1
	join passages p2 on p2.lineid = p1.lineid and p1.pos < p2.pos
	join buslines b on b.line_id=p1.lineid
	join stops s1 on s1.stop_id=p1.stopid
    join stops s2 on s2.stop_id=p2.stopid
where p1.stopid = p2.stopid 

group by concat(b.company,b.number)

order by nbDoublon desc, concat(b.company,b.number);

/*

# ligne, longueur, nbDoublon, doublons, pos_doublons

LRT81, 12, 4, St Andrew Square,Comely Bank,Crewe Toll,Muirhouse, 5,6,7,8

LRT81A, 13, 4, St Andrew Square,Comely Bank,Crewe Toll,Muirhouse, 6,7,8,9

LRT12, 18, 3, Niddrie,Haymarket,Broomhouse, 1,5,8

...

*/



/*

e) Eliminez les points de départ et d'arrivée des lignes circulaires (celles où le premier et le dernier arrêt coïncident).

*/

select concat(b.company,b.number) as ligne,
    b.nbr_stops as longueur,    
    round(count(s1.stop_id)) as nbDoublon,
    group_concat(distinct s1.name order by p1.pos) as doublons,
    group_concat(distinct p1.pos) as pos_doublons
    
from passages p1
	join passages p2 on p2.lineid = p1.lineid and p1.pos < p2.pos
	join buslines b on b.line_id=p1.lineid and b.nbr_stops != p1.pos
	join stops s1 on s1.stop_id=p1.stopid
    join stops s2 on s2.stop_id=p2.stopid
where p1.stopid = p2.stopid and p1.pos != p2.pos and b.nbr_stops != p2.pos

group by concat(b.company,b.number)

order by nbDoublon desc, concat(b.company,b.number);

/*

# ligne, longueur, nbDoublon, doublons, pos_doublons

LRT81, 12, 3, St Andrew Square,Comely Bank,Crewe Toll, 5,6,7

LRT81A, 13, 3, St Andrew Square,Comely Bank,Crewe Toll, 6,7,8

LRT12, 18, 2, Haymarket,Broomhouse, 5,8

...

*/

-- 8 row(s) returned