-- Nom de ligne ( concaténation de la companie et du numéro)
select concat(company,number) from buslines;

-- Calculer les lignes
select concat(b.company, b.number) as ligne,
	   p.pos as rang,
	   s.name as arret
from passages p
	join stops s on s.stop_id = p.stopid
    join buslines b on b.line_id = p.lineid
    -- where concat(b.company, b.number) = 'FF56'
    order by ligne, p.pos;

-- Calculer les tronçons
select concat(b.company, b.number) as ligne,
	 p1.pos as rang, s1.name as arrêt_1,
	 p2.pos as rang, s2.name as arrêt_2
from passages p1
	join passages p2 on p2.lineid=p1.lineid and p2.pos=p1.pos+1
	join buslines b on b.line_id=p1.lineid
	join stops s1 on s1.stop_id=p1.stopid
	join stops s2 on s2.stop_id=p2.stopid
where concat(b.company, b.number) = 'LRT13'
order by p1.pos;

-- Calculer les distances entre arrêts à partir de leur coordonnées GPS
select 
	p1.lineid as ligne,
    concat(b.company, b.number) as nom_ligne,
	p1.pos, p2.pos,
    s1.name as arret1,
    s2.name as arret2,
	round(st_distance_sphere(point(s1.longitude,s1.latitude), point(s2.longitude,s2.latitude))/1000,3)as lng_km
	from passages p1
	join passages p2 on p2.lineid = p1.lineid and p2.pos = p1.pos +1 
    join stops s1 on s1.stop_id = p1.stopid
    join stops s2 on s2.stop_id = p2.stopid
    join buslines b on b.line_id = p1.lineid
order by p1.lineid, p1.pos;

-- Calculer les distances des tronçons
select 
	p1.lineid as ligne,
    concat(b.company, b.number) as nom_ligne,
	round(sum(st_distance_sphere(point(s1.longitude,s1.latitude), point(s2.longitude,s2.latitude)))/1000,3)as lng_km
	from passages p1
	join passages p2 on p2.lineid = p1.lineid and p2.pos = p1.pos +1 
    join stops s1 on s1.stop_id = p1.stopid
    join stops s2 on s2.stop_id = p2.stopid
    join buslines b on b.line_id = p1.lineid
    group by b.line_id
order by p1.lineid, p1.pos;

-- Q1 : Quels sont les stops qui sont des têtes de ligne ?
select p.stopid, p.lineid
	from passages p
where p.pos=1
order by p.stopid
limit 12;

-- Q2 : Modifiez la requête précédente pour faire apparaitre aussi les noms des stops en plus de leur identifiant
select p.stopid, s.name, p.lineid
	from passages p
    join stops s on s.stop_id = p.stopid
where p.pos=1
order by p.stopid
limit 12;

-- Q3 : Modifiez la requête précédente pour faire apparaitre aussi les noms des lignes en plus de leur identifiant
select p.stopid, s.name, p.lineid, concat(b.company,B.number) as line
	from passages p
    join stops s on s.stop_id = p.stopid
    join buslines b on b.line_id = p.lineid
where p.pos=1
order by p.stopid
limit 12;

-- Q4 : Combien y a-t-il de tronçons de lignes ? 
select count(*) as nb_tronçons
	from passages p1
	join passages p2 on p1.lineid = p2.lineid and p1.pos = p2.pos + 1
order by p1.lineid, p1.pos;

-- Q5 : Modifiez la requête précédente pour trouver la longueur totale du réseau
select 
	round(sum(st_distance_sphere(point(s1.longitude,s1.latitude), point(s2.longitude,s2.latitude)))/1000,3)as lng_tot_km
		from passages p1
		join passages p2 on p2.lineid = p1.lineid and p2.pos = p1.pos +1 
		join stops s1 on s1.stop_id = p1.stopid
		join stops s2 on s2.stop_id = p2.stopid
		join buslines b on b.line_id = p1.lineid
order by p1.lineid, p1.pos;

-- Q6 : Modifiez la requête précédente pour trouver la longueur d'une ligne donnée par son nom. Prenez la ligne MAC100 comme exemple, elle fait plus de 100 km.
select 
	concat(b.company,b.number) as line,
    b.nbr_stops,
	round(sum(st_distance_sphere(point(s1.longitude,s1.latitude), point(s2.longitude,s2.latitude)))/1000,3)as lng_tot_km
		from passages p1
		join passages p2 on p2.lineid = p1.lineid and p2.pos = p1.pos +1 
		join stops s1 on s1.stop_id = p1.stopid
		join stops s2 on s2.stop_id = p2.stopid
		join buslines b on b.line_id = p1.lineid
        group by b.line_id
        having line = 'MAC100'
order by p1.lineid, p1.pos;


-- Q7 : UNE QUESTION PLUS DIFFICILE
/*Trouvez toutes les lignes qui « avancent à petits pas » : la distance entre deux arrêts successifs
doit toujours être inférieure à 2,5 km. On admet cependant qu’un tronçon (au plus un) de la ligne
échappe à cette règle. Donnez aussi la longueur totale de la ligne. Classez par nombre de
tronçons longs, puis par longueur totale de la ligne.*/

/*
select 
    concat(b.company, b.number) as nom_ligne,
    b.nbr_stops, 
		case when round(st_distance_sphere(point(s1.longitude,s1.latitude), point(s2.longitude,s2.latitude))/1000,3) < 2.5 
			 then 'Petits trajets'
			 else 'Longs trajets'
		end as Type,
	round(st_distance_sphere(point(s1.longitude,s1.latitude), point(s2.longitude,s2.latitude))/1000,3)as lng_km
	from passages p1
	join passages p2 on p2.lineid = p1.lineid and p2.pos = p1.pos +1 
    join stops s1 on s1.stop_id = p1.stopid
    join stops s2 on s2.stop_id = p2.stopid
    join buslines b on b.line_id = p1.lineid
    group by nom_ligne
order by p1.lineid, p1.pos;


-- Vérifier 
select 
	concat(b.company, b.number) as ligne,
    b.nbr_stops,
	count(p.pos) AS nb_pass
from buslines b
join passages p on p.lineid = b.line_id
join stops s on s.stop_id = p.stopid
group by b.line_id -- ,concat(b.company, b.number)
having nb_pass != b.nbr_stops
order by b.line_id, p.pos;

select 
	concat(b.company, b.number) as ligne,
    p1.pos, 
    s1.name as arret1,
    p2.pos,
    s2.name as arret2,
	round(st_distance_sphere(point(s1.longitude,s1.latitude), point(s2.longitude,s2.latitude))/1000,3) as dists1s2
	
    
	from buslines b
		join passages p1 on p1.lineid = b.line_id
		join stops s1 on s1.stop_id = p1.stopid
		join passages p2 on p2.lineid = b.line_id and p2.pos = p1.pos +1
		join stops s2 on s2.stop_id = p2.stopid
        
	-- where round(st_distance_sphere(point(s1.longitude,s1.latitude), point(s2.longitude,s2.latitude))/1000,3) < 2.5
    group by line_id
	having (dists1s2 < 2.5) < 2
order by b.line_id, p1.pos;
*/

-- Q7 : UNE QUESTION PLUS DIFFICILE
/*Trouvez toutes les lignes qui « avancent à petits pas » : la distance entre deux arrêts successifs
doit toujours être inférieure à 2,5 km. On admet cependant qu’un tronçon (au plus un) de la ligne
échappe à cette règle. Donnez aussi la longueur totale de la ligne. Classez par nombre de
tronçons longs, puis par longueur totale de la ligne.*/

select 
	concat(b.company, b.number) as ligne,
	b.nbr_stops,
    round(sum(st_distance_sphere(point(s1.longitude,s1.latitude), point(s2.longitude,s2.latitude)))/1000,3) as longtot_km,
	sum(case 
    when round(st_distance_sphere(point(s1.longitude,s1.latitude), point(s2.longitude,s2.latitude))/1000,3) <= 2.5
    then 0 else 1 end) as nbrTronçonLong
    
from buslines b
		join passages p1 on p1.lineid = b.line_id
		join stops s1 on s1.stop_id = p1.stopid
		join passages p2 on p2.lineid = b.line_id and p2.pos = p1.pos +1
		join stops s2 on s2.stop_id = p2.stopid
        
        group by line_id
        having nbrTronçonLong <2
        order by nbrTronçonLong, longtot_km;
