-- Sujet 2

-- Q1: Quels sont les arrêts situés sur une ligne passant par Willowbrae ?
select s1.name as arret1,
	   s2.name as arret2
from passages p1
	join passages p2 on p2.lineid=p1.lineid 
	join buslines b on b.line_id=p1.lineid
	join stops s1 on s1.stop_id=p1.stopid
	join stops s2 on s2.stop_id=p2.stopid
where s1.name = 'Willowbrae';
    
 -- Q2: Quels sont les arrêts situés sur une ligne passant par Willowbrae ? Distance à Willowbrae
 select s1.name as arret1,
	    s2.name as arret2,
        round((st_distance_sphere(point(s1.longitude,s1.latitude), point(s2.longitude,s2.latitude)))/1000,3)as dist
from passages p1
	join passages p2 on p2.lineid=p1.lineid 
	join buslines b on b.line_id=p1.lineid
	join stops s1 on s1.stop_id=p1.stopid
	join stops s2 on s2.stop_id=p2.stopid
where s1.name = 'Willowbrae';
 
 -- Q3 : Les arrêts B voisins d'un arrêt A sont définis comme les arrêts B situés sur une ligne 
 -- de bus passant par A et distant de A de moins de 1 km. Trouvez toutes les paires d'arrêts voisins.
 
  select s1.stop_id,
		 s1.name,
		 s2.stop_id,
		 s2.name,
        round((st_distance_sphere(point(s1.longitude,s1.latitude), point(s2.longitude,s2.latitude)))) as dist,
        b.line_id
        
from passages p1
	join passages p2 on p2.lineid=p1.lineid
	join buslines b on b.line_id=p1.lineid
	join stops s1 on s1.stop_id=p1.stopid 
	join stops s2 on s2.stop_id=p2.stopid

where round(st_distance_sphere(point(s1.longitude,s1.latitude), point(s2.longitude,s2.latitude))) < 1000
	and s1.name != s2.name
order by s1.stop_id,s2.stop_id;

-- Q4: Donnez pour chaque arrêt le nombre d'arrêts voisins. Limitez aux arrêts ayant au moins 3 voisins.
-- Classez par nombre de voisins.

  select group_concat(distinct s1.name),
		count(distinct s2.name) as nbVoisin
        
from passages p1
	join passages p2 on p2.lineid=p1.lineid 
	join buslines b1 on b1.line_id=p1.lineid
    join buslines b2 on b2.line_id=p2.lineid
	join stops s1 on s1.stop_id=p1.stopid 
	join stops s2 on s2.stop_id=p2.stopid 

where round(st_distance_sphere(point(s1.longitude,s1.latitude), point(s2.longitude,s2.latitude))) < 1000
	and s1.name != s2.name 
    group by s1.stop_id 
    having nbVoisin >= 3 
order by nbVoisin desc;


-- Sujet 3

-- Q1 : Trouvez toutes les paires d'arrêts très proche l'un de l'autre(moins de 150m).
-- Indiquez aussi les identifiants de ces arrêts. Evitez les doublons (de paires).

select s1.name as arret1,
	   s1.stop_id,
       s1.latitude,
       s1.longitude,
       s2.name as arret2,
	   s2.stop_id,
       s2.latitude,
       s2.longitude,
       (st_distance_sphere(point(s1.longitude,s1.latitude), point(s2.longitude,s2.latitude)))/1000 as distance
        
from stops s1
	join stops s2 on s2.stop_id < s1.stop_id

having distance <150/1000
order by distance ;
