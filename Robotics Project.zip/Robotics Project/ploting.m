function ploting(H)

    X1 =[H(1,4);H(1,1)*50+H(1,4)]; % H(1,4) --> ligne 1 colonne 4
    Y1 =[H(2,4);H(2,1)*50+H(2,4)];
    Z1 =[H(3,4);H(3,1)*50+H(3,4)];

 

    X2 =[H(1,4);H(1,2)*50+H(1,4)];
    Y2 =[H(2,4);H(2,2)*50+H(2,4)];
    Z2 =[H(3,4);H(3,2)*50+H(3,4)];



    X3 =[H(1,4);H(1,3)*50+H(1,4)];
    Y3 =[H(2,4);H(2,3)*50+H(2,4)];
    Z3 =[H(3,4);H(3,3)*50+H(3,4)];
    


    p = plot3(X1,Y1,Z1,'r','LineWidth',3);
    p2 = plot3(X2,Y2,Z2,'g','LineWidth',3);
    p3 = plot3(X3,Y3,Z3,'b','LineWidth',3);
    
    xlabel('X');
    ylabel('Y');
    zlabel('Z');
    axis([-400 400 -400 400 0 800]);
    grid on;
    hold on; 
end
