% MGD7
function T=MGD7(teta, robot)

    N=max(size(robot.alpha));
    Tp=eye(4);
    
%   Calcul avec formule:
    for i=1:N
       
        T=Tp*Rotx(robot.alpha(i))*Transx(robot.d(i))*Rotz(teta(i))*Transz(robot.r(i));
        Tp=T;
        
    end
    
    T= Tp*Rotx(0)*Transx(0)*Rotz(pi)*Transz(123);
end
