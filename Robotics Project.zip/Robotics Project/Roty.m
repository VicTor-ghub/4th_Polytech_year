function M=Roty(teta)

    M=[ cos(teta) 0  sin(teta) 0;0 1 0 0; -sin(teta) 0 cos(teta) 0; 0 0 0 1];
    
end 
