
function [q,dq,d2q] = Poly3(qf,qi,tf,t)
    
    a0 = qi;
    a1 = [0;0;0;0;0;0];
    a2 = (3*(qf-qi))/(tf.^2);
    a3 = (-2*(qf-qi))/(tf.^3);

    % Loi Polynomiale

    for i=1:6

        q(i)= a0(i) + a1(i)*t + a2(i)*(t.^2) + a3(i)*(t.^3);

        dq(i)= a1(i) + 2*a2(i)*t + 3*a3(i)*(t.^2);

        d2q(i)= 2*a2(i) + 6*a3(i)*t;

    end 
end
    