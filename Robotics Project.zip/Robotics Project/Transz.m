function P=Transz(Pz)

    P=[1 0 0 0; 0 1 0 0; 0 0 1 Pz; 0 0 0 1];
    
end 