
function [param,Q] = Loi_polynomiale(robot,qf,qi, duree)

% Param�tres du trap�ze
    param.qi=qi;
    param.qf=qf;
    tf = duree;
    
    for i=1:6
        
        if (qi(i) < robot.qmin(i) || qf(i) < robot.qmin(i) || qi(i) < robot.qmin(i) || qf(i) < robot.qmin(i))
            
            print('Positions out of range');
            return ;
        end
        
    end
    
    % Variables
    p= 1;
    
    for t=0:0.1:tf

        % Loi Polynomiale
        [q,dq,d2q] = Poly3(qf,qi,tf,t);
        [d2q_max,j] = max(d2q);
        [dq_max,k] = max(dq);

        while (robot.d2q(j) < d2q_max)         % Check acc�l�ration

                tf = tf + 0.1;
                [q,dq,d2q] = Poly3(qf,qi,tf,t);
                [d2q_max,j] = max(d2q);
                [dq_max,k] = max(dq);
        end

        while (robot.dq(k) < dq_max)         % Check vitesse

                tf = tf + 0.1;
                [q,dq,d2q] = Poly3(qf,qi,tf,t);
                [d2q_max,j] = max(d2q);
                [dq_max,k] = max(dq);
        end
        
        % R�cup�ration de la position en fonction du temps 
        % pour chaque articulation  
        for n=1:6
            
            Q(p,n) = q(n);
        end
        p= p+1;
    end
    
    % R�cup�ration des donn�es finales
    param.duree = tf;
    

end