% MGDi
function T=MGDi(teta, robot,i)

    Tp=eye(4);
    
%   Calcul avec formule:
    for i=1:i
       
        T=Tp*Rotx(robot.alpha(i))*Transx(robot.d(i))*Rotz(teta(i))*Transz(robot.r(i));
        Tp=T;
        
    end

end