
function param=CalculeTrapeze(robot,qi,qf,duree)
    
    % Param�tres du trap�ze
    param.qi=qi;
    param.qf=qf;
    param.duree=duree;
    
    for i=1:6
        
        if (qi(i) < robot.qmin(i) || qf(i) < robot.qmin(i) || qi(i) < robot.qmin(i) || qf(i) < robot.qmin(i))
            
            print('Positions out of range');
            return ;
        end
        
    end
    
    for i=1:6
        
        % Distance totale
        delta_q(i) = qf(i)-qi(i);
        
        % Donn�es robot
        Vmax(i) = robot.dq(i);
        Amax(i) = robot.d2q(i);
        
        % R�cup�ration des param�tres du trap�ze pour chaque articulation
        t1(i) = Vmax(i)/Amax(i);
        d_accel(i) = (2*t1(i))^2*Amax(i);
        t_cte(i) = (delta_q(i) - d_accel(i))/Vmax(i);
        t2(i) = t1(i) + t_cte(i);
        tf(i)= t2(i) + t1(i);
       
    end
    
    % Param�tres finaux du trap�ze
    
    [tf_max,j] = max(tf);  % temps final de l'articulation la plus longue
    t1_max = t1(j);
    
    param.tf_max= tf_max;
    param.t1_max= t1_max;
        
    if ( param.tf_max > duree)

        param.duree= tf_max;
    
    else
        param.duree= duree;
        
    end

    % Calcul des vitesses et des acc�l�rations
    for i=1:6
        
        param.Vmax_prime(i) = delta_q(i)/(param.duree - param.t1_max);
        param.Amax_prime(i) = param.Vmax_prime(i)/param.t1_max;
        
    end
    
 
    
    
    
    
    
    
    
    
    
    % En BONUS ???
    
    % Cas des triangles ???
%     if ( t2 < t1)
%         
%         t2 = t1
%     end


    % Cas triangle idem ???
%         if (duree < 2*t1) && (delta_q < Amax*(duree/2)^2)
%            if (t1 < tmin)
%             
%             Param.tmin=t1;
%             
%            end
%             if (tf > tmax)
% 
%             
%             Param.tmax=tf; 
%             
%             end
%         elseif (duree > 2*t1) && (delta_q < 0.5*Amax*(t1/2)^2 + 0.5*Amax*(tf-t2/2)^2 + Vmax*(t2-t1))
%             if (t1 < tmin)
%             
%             Param.tmin=t1;
%             
%            end
%             if (tf > tmax)
%             
%             Param.tmax=tf; 
%             
%             end
%         else 
%             
%             duree=0; % erreur
% 
%         end
        
    
end
       

