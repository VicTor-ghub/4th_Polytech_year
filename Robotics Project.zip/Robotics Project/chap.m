function matchap = chap(mat)
    
    matchap = [0 -mat(3) mat(2);
               mat(3) 0 -mat(1);
               -mat(2) mat(1) 0];
    
end