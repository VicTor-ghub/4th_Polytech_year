% MGD
function T=MGD(teta, robot)

    N=max(size(robot.alpha));
    Tp=eye(4);
    
    % Conditions initiales
    teta(2) = teta(2)- 1.4576453;
    teta(3) = teta(3)- 0.898549163;
    teta(7) = teta(7) + pi;
    
    % Calcul avec formule:
    for i=1:N
       
        T=Tp*Rotx(robot.alpha(i))*Transx(robot.d(i))*Rotz(teta(i))*Transz(robot.r(i));
        Tp=T;
        
    end
    
    T= Tp*Rotx(0)*Transx(0)*Rotz(teta(7))*Transz(123);
    Tp=T;
    T= Tp*Rotx(0)*Transx(0)*Rotz(teta(8))*Transz(112);
end

           