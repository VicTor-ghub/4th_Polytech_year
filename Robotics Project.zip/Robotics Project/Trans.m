function P=Trans(Px,Py,Pz)

    P=Transx(Px)*Transy(Py)*Transz(Pz);
    
end 