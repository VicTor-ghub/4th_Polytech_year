
function [transfo, x, y, z] = matrice_mgd(robot, teta)

    N = max(size(robot.alpha));
    Tp=eye(4,4);
    X=zeros(4,4);
    
   teta(2) = teta(2) - 1.4576453;
   teta(3) = teta(3) - 0.898549163;
   teta(7) = teta(7) + pi;

    for i = 1:N
        transfo = Tp*Rotx(robot.alpha(i))*Transx(robot.d(i))*Rotz(teta(i))*Transz(robot.r(i));
        Tp=transfo;
        
       
       % disp('matrice de passage');
       % disp(Tp); 
        
        %[p, p2, p3] = ploting(Tp, 1000);
        
        x(i,1) = transfo(1,4);
        y(i,1) = transfo(2,4);
        z(i,1) = transfo(3,4);
        
        
%         figure
%         p2 = ploting(Tp*Rx(robot.alpha(i))*Tx(robot.d(i)),'r',3);
%         p3 = ploting(Tp*Ry(robot.alpha(i))*Ty(robot.d(i)),'g',3);
%         p4 = ploting(Tp*Rz(robot.alpha(i))*Tz(robot.d(i)),'b',3);
       
        %plot3([X(1,4);Tp(1,4)], [X(2,4);Tp(2,4)], [X(3,4);Tp(3,4)], 'k', 'linewidth',3);
        X=Tp;
        hold on;
        
        
    end

end