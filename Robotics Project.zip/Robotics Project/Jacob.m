% MGD
function J=Jacob(teta, robot, P)

    N=max(size(robot.alpha));
    Tp=eye(4);
    
    OjP=zeros(3,N);
    aj=zeros(3,N);
    J=zeros(6,N);

% Conditions initiales
    teta(2) = teta(2)- 1.4576453;
    teta(3) = teta(3)- 0.898549163;
    teta(7) = teta(7) + pi;
    
%   Calcul avec formule:
    for i=1:N
       
        T=Tp*Rotx(robot.alpha(i))*Transx(robot.d(i))*Rotz(teta(i))*Transz(robot.r(i));
    
        OjP(:,i)=P(:)-T(1:3,4);
        aj(:,i)=T(1:3,3);
        J(:,i)=[cross(aj(:,i),OjP(:,i)); aj(:,i)];
%         J(1:3,i)=cross(aj(:,i),OjP(:,i));
%         J(4:6,i)=aj(:,i);
        Tp=T;
    end
    
    T= Tp*Rotx(0)*Transx(0)*Rotz(0)*Transz(123);
    OjP(:,7)=P-T(1:3,4);
    aj(:,7)=T(1:3,3);
    J(:,7)=[cross(aj(:,7),OjP(:,7)); aj(:,7)];
%     J(1:3,7)=cross(aj(:,7),OjP(:,7));
%     J(4:6,7)=aj(:,7);
    Tp=T;
    
    T= Tp*Rotx(0)*Transx(0)*Rotz(0)*Transz(112);
    OjP(:,8)=P-T(1:3,4);
    aj(:,8)=T(1:3,3);
    J(:,8)=[cross(aj(:,8),OjP(:,8)); aj(:,8)];
%     J(1:3,8)=cross(aj(:,8),OjP(:,8));
%     J(4:6,8)=aj(:,8);
    
end



           

           