function P=Transx(Px)

    P=[1 0 0 Px; 0 1 0 0; 0 0 1 0; 0 0 0 1];
    
end 