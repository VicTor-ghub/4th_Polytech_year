function [teta, robot] = create_robot_theo(teta1, teta2, teta3, teta4, teta5, teta6)
    
    
    robot.alpha = [0.0, -pi/2, 0.0, -pi/2, pi/2, -pi/2, 0.0, 0.0];
    robot.r=[159, 0.0, 0.0, 258, 0.0, 0.0, 123, 112];
    robot.d=[0.0, 0.0, 265.69, 30, 0.0, 0.0, 0.0, 0.0];
    
    %Commande 
    q0=[teta1, teta2, teta3, teta4, teta5, teta6, 0.0 , 0.0];
    %q0=q0*(180/pi);
    teta=q0;
    
    %%%%%% AVEC DECALAGES 
%     robot.theta = [0.0, 0 - 1.4576453, 0 - 0.898549163, 0.0, 0.0, 0.0, 0.0, 0.0];
%     robot.alpha = [0.0, -pi/2, 0.0, -pi/2, pi/2, -pi/2, pi, 0.0];
%     robot.r=[159, 0.0, 0.0, 258, 0.0, 0.0, 123, 112];
%     robot.d=[0.0, 0.0, 265.69, 30, 0.0, 0.0, 0.0, 0.0];
    

    %% declaration q, dq, d2q et Cmax (couple max)
    
    robot.qmin=[-pi, -pi/2, -pi/2, -pi, -pi/2, -pi];
    robot.qmax=[pi, pi/2, 3*pi/4, pi,  pi/2, pi];
    robot.dq=[3.3, 3.3, 3.3, 3.3, 3.3, 3.3 ];
    robot.d2q=[30, 30, 30, 30, 30, 30];
    robot.Cmax=[44.2, 44.2, 21.142, 21.142, 6.3, 6.3];
    
end