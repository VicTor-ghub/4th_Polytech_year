function M=RTL(psy, teta, phi)

    M= Rotz(phi)* Roty(teta) *Rotx(psy) ;

end 
