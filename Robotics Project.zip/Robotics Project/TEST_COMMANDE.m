clear;
clc;
clf;
close all;

% Cr�ation du robot 
[teta, robot] = create_robot(0,0,0,0,0,0);

% Position d�part et arriv�e
qi = [0 0 0 0 0 0];
qf = [0.5,0.1,0.3,0.1,0.2,0.1];

% Initialisation des matrices
q = zeros(100, 6);
qp = zeros(100, 6);
qpp = zeros(100, 6);
qPoly = zeros(100, 6);
qpPoly = zeros(100, 6);
qppPoly = zeros(100, 6);
Param = CalculeTrapeze(robot, qi, qf, 1);
i = 1;
Tmax = Param.tf_max;
for t = 0:0.01:Tmax
    [q(i,:), qp(i,:), qpp(i,:)] = CalculeQ(Param, t);
    [qPoly(i,:), qpPoly(i,:), qppPoly(i,:)] = LoiPolynomiale(Param, t, Param.tf_max);
    i = i + 1;
end

n = Tmax/0.01+1;
t = linspace(0, Tmax, n);
u = i -1;
% Affichage de la loi trap�ze
figure(1);
subplot(2,2,1);
plot(t, q(1:length(t),1), t, q(1:length(t),2), t, q(1:length(t),3) ,t, q(1:length(t),4) ,t, q(1:length(t),5), t, q(1:length(t),6));
legend({'q1(t)','q2(t)', 'q3(t)', 'q4(t)', 'q5(t)', 'q6(t)'},'Location','southwest')
title('q(t) des 6 joints');
xlabel('t');

subplot(2,2,[3,4]);
plot(t, qp(1:length(t),1), t, qp(1:length(t),2), t, qp(1:length(t),3) ,t, qp(1:length(t),4) ,t, qp(1:length(t),5), t, qp(1:length(t),6));
%legend({'qp1(t)','qp2(t)', 'qp3(t)', 'qp4(t)', 'qp5(t)', 'qp6(t)'},'Location','southwest')
title('qp(t) des 6 joints');
xlabel('t');

subplot(2,2,2);
plot(t, qpp(1:length(t),1), t, qpp(1:length(t),2), t, q(1:length(t),3) ,t, q(1:length(t),4) ,t, q(1:length(t),5), t, q(1:length(t),6));
%legend({'qpp1(t)','qpp2(t)', 'qpp3(t)', 'qpp4(t)', 'qpp5(t)', 'qpp6(t)'},'Location','southwest')
title('qpp(t) des 6 joints');
xlabel('t');



% Affichage de la loi polynomiale(t)
figure(2);
subplot(2,2,1);
plot(t, qPoly(1:length(t),1), t, qPoly(1:length(t),2), t, qPoly(1:length(t),3) ,t, qPoly(1:length(t),4) ,t, qPoly(1:length(t),5), t, qPoly(1:length(t),6));
legend({'q1(t)','q2(t)', 'q3(t)', 'q4(t)', 'q5(t)', 'q6(t)'},'Location','southwest')
title('qPoly(t) des 6 joints');
xlabel('t');


subplot(2,2,[3,4]);
plot(t, qpPoly(1:length(t),1), t, qpPoly(1:length(t),2), t, qpPoly(1:length(t),3) ,t, qpPoly(1:length(t),4) ,t, qpPoly(1:length(t),5), t, qpPoly(1:length(t),6));
%legend({'qp1(t)','qp2(t)', 'qp3(t)', 'qp4(t)', 'qp5(t)', 'qp6(t)'},'Location','southwest')
title('qpPoly(t) des 6 joints');
xlabel('t');

subplot(2,2,2);
plot(t, qppPoly(1:length(t),1), t, qppPoly(1:length(t),2), t, qppPoly(1:length(t),3) ,t, qppPoly(1:length(t),4) ,t, qppPoly(1:length(t),5), t, qppPoly(1:length(t),6));
%legend({'qpp1(t)','qpp2(t)', 'qpp3(t)', 'qpp4(t)', 'qpp5(t)', 'qpp6(t)'},'Location','southwest')
title('qppPoly(t) des 6 joints');
xlabel('t');


