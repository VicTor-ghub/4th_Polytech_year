function bool = equal(Xd,Xe,diff,diffz)
    
    Zob=abs(Xd-Xe);
    
    if(Zob(1) < diff && Zob(2) < diff && Zob(3) < diffz)
        bool = 0;
    else
        bool=1;
    end
    
end
