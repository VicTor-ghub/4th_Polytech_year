function P=Transy(Py)

    P=[1 0 0 0; 0 1 0 Py; 0 0 1 0; 0 0 0 1];
    
end 