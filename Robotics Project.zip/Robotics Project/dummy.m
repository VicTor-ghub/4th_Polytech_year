clear all

% Variable temporelle
dt=0.01;

% Cr�ation du robot 
[teta, robot] = create_robot(0,pi/4,pi/4,0,pi/4,0);

disp('Open Vrep Api............');
[vrep, clientID]=VrepOpenApi();

%%%%%%%%%%%%%%%%%%  POUR MODE SYNCHRO %%%%%%%%%%%%%%%%%%%%%
% configure le mode synchronous
vrep.simxSynchronous(clientID,true)

% Configure le pas de simulation � dt
% ATTENTION  pris en compte uniquement si dt=Custom sur VREP
vrep.simxSetFloatingParameter(clientID,vrep.sim_floatparam_simulation_time_step,dt,vrep.simx_opmode_oneshot)

% d�marre la sumulation en mode oneshot_wait (un pas et attend)
vrep.simxStartSimulation(clientID,vrep.simx_opmode_oneshot_wait);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

disp('Retrieving all the joint handles.......');

%r�cup�ration des handles des articulations (joint1..joint6)
for idobj=1:6,
        objectName=strcat('joint',num2str(idobj));
        listObjects(idobj).name=objectName;
end
[all_ok, listObjects]=VrepGetHandles(vrep, clientID, listObjects);

if all_ok == false
       disp('An error occured while retrieving the object handles ==> stop simulation');
       return;
end

%-----------------
% Simulation
%-----------------
N=2000;
q= teta;
qc=[0;0;0;0;0;0];

% Croquis � dessiner
% PDD = {[100;100;0],[300;-100;0],[330;-50;0],[330;250;0],[300;300;0],[100;100;0], [300;167;0], [300;300;0], [330;250;0], [300;167;0], [330;100;0], [300;34;0], [330;-50;0], [300;-100;0], [300;34;0], [300;167;0], [300;34;0], [100;100;0]}; 
% N=max(size(PDD));

% R�cup�ration position initiale
[T,P]= MGD_position(q, robot);    

% Position d�sir�e
Pd = [100;100;20];

% Vitesse d�sir�e
Pd_dot = [0;0;0];

% Orientation d�sir�e
Ad = [-1 0 0;
       0 1 0;
       0 0 -1];
   
for i=1:N,
    % Evolution du point d�sir�
    % Pd=PDD{i};
    
    % while(equal(Pd,Pe,1))
    % MGD
    T= MGD(q, robot);
    Pe= T(1:3,4);        % Position r�elle
    Ae= T(1:3,1:3);      % Orientation r�elle
    
    % Erreur de position
    Ep= Pd - Pe;
    Kp= 1;              % Gain de r�activit�
    
    % Erreur d'orientation
    A= Ad*Ae';
    A0= [A(3,2) - A(2,3);
         A(1,3) - A(3,1);
         A(2,1) - A(1,2)];
     
    E0= 0.5*A0;
    K0= 1;
    
    % Laplacien inverse
    sechap= chap(Ae(1:3,1));
    sdchap= chap(Ad(1:3,1));

    nechap= chap(Ae(1:3,2));
    ndchap= chap(Ad(1:3,2));

    aechap= chap(Ae(1:3,3));
    adchap= chap(Ad(1:3,3));

    L= (-0.5)*(sechap*sdchap + nechap*ndchap + aechap*adchap);
    
    L_inv= pinv(L);
     
    % MUX
    Pe_dot = Pd_dot + Ep*Kp;
    We= L_inv*K0*E0;
    
    Mux =[Pe_dot; We];
    %Mux = Pe_dot;
    
    % Jacobienne
    J=Jacob(q, robot, Pd);
    %test= J(1:3,1:6);
    pseudo= pinv(J);
    
    % Vitesse
    q_dot= pseudo(1:6,1:6)*Mux;
    
    for j=1:6,
        if (q_dot(j) > robot.dq(j)) 
            q_dot(j) = robot.dq(j);
            
        end
    end
    
    % Commande 
    qc= qc + q_dot.*dt;
    
    for j=1:6,
        if (qc(j) > robot.qmax(j)) 
            qc(j) = robot.qmax(j);
            
        elseif (qc(j) < robot.qmin(j)) 
            qc(j) = robot.qmin(j);
            
        end
    end
   
    % lien client
    vrep.simxPauseCommunication(clientID, 1);
    % on envoit toutes les consignes
    vrep.simxSetJointTargetPosition(clientID, listObjects(1).handle , qc(1), vrep.simx_opmode_oneshot);
    vrep.simxSetJointTargetPosition(clientID, listObjects(2).handle , qc(2), vrep.simx_opmode_oneshot);
    vrep.simxSetJointTargetPosition(clientID, listObjects(3).handle , qc(3), vrep.simx_opmode_oneshot);
    vrep.simxSetJointTargetPosition(clientID, listObjects(4).handle , qc(4), vrep.simx_opmode_oneshot);
    vrep.simxSetJointTargetPosition(clientID, listObjects(5).handle , qc(5), vrep.simx_opmode_oneshot);
    vrep.simxSetJointTargetPosition(clientID, listObjects(6).handle , qc(6), vrep.simx_opmode_oneshot);
    
    % r�active VREP et applique toutes les consignes simultan�ment
    vrep.simxPauseCommunication(clientID, 0);

    %Active 1 pas de simulation :
    vrep.simxSynchronousTrigger(clientID);

    %lecture des position dans vrep
    [err(1), q(1)]=vrep.simxGetJointPosition(clientID, listObjects(1).handle, vrep.simx_opmode_oneshot);
    [err(2), q(2)]=vrep.simxGetJointPosition(clientID, listObjects(2).handle, vrep.simx_opmode_oneshot);
    [err(3), q(3)]=vrep.simxGetJointPosition(clientID, listObjects(3).handle, vrep.simx_opmode_oneshot);
    [err(4), q(4)]=vrep.simxGetJointPosition(clientID, listObjects(4).handle, vrep.simx_opmode_oneshot);
    [err(5), q(5)]=vrep.simxGetJointPosition(clientID, listObjects(5).handle, vrep.simx_opmode_oneshot);
    [err(6), q(6)]=vrep.simxGetJointPosition(clientID, listObjects(6).handle, vrep.simx_opmode_oneshot);
    
    end
%end

pause(2)
%Arrete le simulateur
vrep.simxStopSimulation(clientID,vrep.simx_opmode_oneshot_wait);

% Ferme la connexion r�seau à VREP
vrep.simxFinish(-1);

vrep.delete();
