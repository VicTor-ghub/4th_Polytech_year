% Simulateur 

clear all

% Variable temporelle
dt=0.01;

% Cr�ation du robot 
[teta, robot] = create_robot(0,0,0,0,0,0);

%-----------------
% Simulation
%-----------------

N=400;
q= teta;
qc=[0;0;0;0;0;0];
We=[0;0;0];

hold on
grid on
axis([-400 400 -400 400 0 800]);
    
    % Position d�sir�e
    Pd = [300;100;200];

    % Vitesse d�sir�e
    Pd_dot = [0;0;0];
    
    % Orientation d�sir�e
    Ad = [-1 0 0;
           0 1 0;
           0 0 -1];
   % MGD
    T=MGD_affich(q, robot);
    Pe= T(1:3,4);        % Position r�elle
    Ae= T(1:3,1:3);     % Orientation r�elle
       
while equal(Pd,Pe,0.1)
    
    % MGD
    T=MGD(q, robot);
    Pe= T(1:3,4);        % Position r�elle
    Ae= T(1:3,1:3);     % Orientation r�elle
    
    % Erreur de position
    Ep= Pd - Pe;
    Kp= 1;              % Gain de r�activit�
    
    % Erreur d'orientation
    A= Ad*Ae';
    A0= [A(3,2) - A(2,3);
         A(1,3) - A(3,1);
         A(2,1) - A(1,2)];
     
    E0= 1/2*A0;
    K0= 2;
    
    % Laplacien inverse
    sechap= chap(Ae(1:3,1));
    sdchap= chap(Ad(1:3,1));

    nechap= chap(Ae(1:3,2));
    ndchap= chap(Ad(1:3,2));

    aechap= chap(Ae(1:3,3));
    adchap= chap(Ad(1:3,3));

    L= -0.5*(sechap*sdchap + nechap*ndchap + aechap*adchap);
    
    L_inv= pinv(L);
     
    % MUX
    Pe_dot = Pd_dot + Ep*Kp;
    %We= L_inv*K0*E0;
    
    Mux = [Pe_dot; We];
    
    % Jacobienne
    J=Jacob(q, robot, Pd);
    pseudo= pinv(J);
    
    % Vitesse
    q_dot= pseudo*Mux;
    
    % Commande 
    qc= qc + q_dot.*dt;
    
    % R�cup�ration de chacune des transfos homog�nes
    OT1=MGDi(teta, robot,1);
    OT2=MGDi(teta, robot,2);
    OT3=MGDi(teta, robot,3);
    OT4=MGDi(teta, robot,4);
    OT5=MGDi(teta, robot,5);
    OT6=MGDi(teta, robot,6);
    OT7=MGD7(teta, robot);
    OT8=MGD(teta, robot);
    
    % Affichage robot
    C='red';
    points = [0 0 0 ;OT1(1:3,4)';OT2(1:3,4)';OT3(1:3,4)';OT4(1:3,4)';OT5(1:3,4)';OT6(1:3,4)';OT7(1:3,4)';OT8(1:3,4)'];
    joints = [1 2;2 3;3 4;4 5;5 6;6 7;7 8;8 9];
    aff_rob = patch('vertices', points, 'faces', joints,'EdgeColor',C);
    
end