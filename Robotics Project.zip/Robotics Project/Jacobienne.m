function J = Jacobienne(robot, P, teta)

    N=length(robot.alpha);

    OjP=zeros(3,N);
    zj=zeros(3,N);
    TransfoP=eye(4,4);
    J=zeros(6,N);
    
   teta(2) = teta(2) - 1.4576453;
   teta(3) = teta(3) - 0.898549163;
   teta(7) = teta(7) + pi;
    
    for i = 1:N 
        MatTransfo = TransfoP*Rotx(robot.alpha(i))*Transx(robot.d(i))*Rotz(teta(i))*Transz(robot.r(i));
        TransfoP = MatTransfo;
        OjP(:,i)=P(:)-MatTransfo(1:3,4);
        zj(:,i)=MatTransfo(1:3,3);
        J(:,i)=[cross(zj(:,i),OjP(:,i)); zj(:,i)];
    end
   
end