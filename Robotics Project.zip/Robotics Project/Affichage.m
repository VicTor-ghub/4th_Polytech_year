%Affichage

clear

%Cr&ation du robot
[teta, robot] = create_robot(0,0,0,0,0,0);  

% R�cup�ration de chacune des transfos homog�nes
OT1=MGDi(teta, robot,1);
OT2=MGDi(teta, robot,2);
OT3=MGDi(teta, robot,3);
OT4=MGDi(teta, robot,4);
OT5=MGDi(teta, robot,5);
OT6=MGDi(teta, robot,6);
OT7=MGD7(teta, robot);
OT8=MGD(teta, robot);

%Cr�ation du rep�re R0 et de l'origine
vecteur =[50;50;50];

% % Trac� du robot
% 
hold on
grid on
axis([-400 400 -400 400 0 800]);
C='red';

points = [0 0 0 ;OT1(1:3,4)';OT2(1:3,4)';OT3(1:3,4)';OT4(1:3,4)';OT5(1:3,4)';OT6(1:3,4)';OT7(1:3,4)';OT8(1:3,4)'];
joints = [1 2;2 3;3 4;4 5;5 6;6 7;7 8;8 9];
aff_rob = patch('vertices', points, 'faces', joints,'EdgeColor',C);
    
MGD_affich(teta,robot);

%Trac� du rep�re R0
% scal =50;
% 
% C='blue';
% R0 = [0 0 0; 1 0 0; 0 1 0; 0 0 1];
% F = [1 2;1 3; 1 4];
% aff_rep0 = patch('vertices', R0, 'faces', F,'EdgeColor',C);
% 
% % Trac� du rep�re R1
% R1= [OT1(1:3,4)';OT1(1:3,1)' + 50*OT1(1:3,4)'];
% F = [1 2; 1 3; 1 4];
% set(aff_rep0,'vertices', R1, 'faces', F,'EdgeColor',C);
 
%  % Trac� du rep�re R2
%  R2= [OT2(1:3,4)';R0(2:4,1:3)];
%  F = [1 2; 1 3; 1 4];
%  set(aff_rep0,'vertices', R2, 'faces', F,'EdgeColor',C);
%  
%  % Trac� du rep�re R3
%  R3= OT3*R0;
%  F = [1 2; 1 3; 1 4];
%  set(aff_rep0,'vertices', R3, 'faces', F,'EdgeColor',C);
 
% % Trac� du rep�re R1
% R4= OT4*R0;
% F = [1 2; 1 3; 1 4];
% aff_rep4 = patch('vertices', R4, 'faces', F,'EdgeColor',C);
% 
% % Trac� du rep�re R1
% R5= OT5*R0;
% F = [1 2; 1 3; 1 4];
% aff_rep5 = patch('vertices', R5, 'faces', F,'EdgeColor',C);
% 
% % Trac� du rep�re R1
% R6= OT6*R0;
% F = [1 2; 1 3; 1 4];
% aff_rep6 = patch('vertices', R6, 'faces', F,'EdgeColor',C);
% 
% % Trac� du rep�re R1
% R7= OT7*R0;
% F = [1 2; 1 3; 1 4];
% aff_rep7 = patch('vertices', R7, 'faces', F,'EdgeColor',C);
% 
% % Trac� du rep�re R8
% R8= OT8*R0;
% F = [1 2; 1 3; 1 4];
% aff_rep8 = patch('vertices', R8, 'faces', F,'EdgeColor',C);
