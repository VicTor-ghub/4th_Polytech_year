function Tj = transfo_repere_hom(theta,alpha,d,r)
    ctheta = cos(theta); stheta = sin(theta);
    calpha = cos(alpha); salpha = sin(alpha);
    Tj = [   ctheta        -stheta       0       d       ;
          calpha*stheta calpha*ctheta -salpha -r*salpha  ;
          salpha*stheta salpha*ctheta calpha  r*calpha   ;
               0             0           0       1       ];
end