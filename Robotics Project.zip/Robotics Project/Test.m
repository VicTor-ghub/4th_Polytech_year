
% Initialisation du robot
[teta, robot] = create_robot(0,0,0,0,0,0);

% Initialisation des variables
duree=5;
qi=robot.qmin;
qf=robot.qmax;

% Calcul du trap�ze
param=CalculeTrapeze(robot,qi,qf,duree);

% Calcul des positions 
Q1 = CalculeQ (robot,qf,qi, param, param.duree);

% Affichage des positions
% figure;
plot(Q1);

% Loi polynomiale
[param,Q2] = Loi_polynomiale(robot,qf,qi, duree);

% Affichage des positions
figure;
plot(Q2);

% Test dummy
T=MGD(teta, robot)