clear all

% Variable temporelle
dt=0.01;

% Cr�ation du robot 
[teta, robot] = create_robot(0,0,0,0,0,0);

disp('Open Vrep Api............');
[vrep, clientID]=VrepOpenApi();

%%%%%%%%%%%%%%%%%%  POUR MODE SYNCHRO %%%%%%%%%%%%%%%%%%%%%
% configure le mode synchronous
vrep.simxSynchronous(clientID,true)

% Configure le pas de simulation � dt
% ATTENTION  pris en compte uniquement si dt=Custom sur VREP
vrep.simxSetFloatingParameter(clientID,vrep.sim_floatparam_simulation_time_step,dt,vrep.simx_opmode_oneshot)

% d�marre la sumulation en mode oneshot_wait (un pas et attend)
vrep.simxStartSimulation(clientID,vrep.simx_opmode_oneshot_wait);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

disp('Retrieving all the joint handles.......');

%r�cup�ration des handles des articulations (joint1..joint6)
for idobj=1:6,
        objectName=strcat('joint',num2str(idobj));
        listObjects(idobj).name=objectName;
end
[all_ok, listObjects]=VrepGetHandles(vrep, clientID, listObjects);

if all_ok == false
       disp('An error occured while retrieving the object handles ==> stop simulation');
       return;
end

%-----------------
% D�pla�ement par Loi Trap�ze
%-----------------

% Initialisation des variables
duree=10;
qi=teta;
qf=[0;pi/6;pi/4;0;pi/3;0];

% Calcul du trap�ze
param=CalculeTrapeze(robot,qi,qf,duree);

% Calcul des positions 
Q = CalculeQ (robot,qf,qi, param, param.duree);
M= max(size(Q));

for i=1:M,
    
     % lien client
    vrep.simxPauseCommunication(clientID, 1);
    % on envoit toutes les consignes
    vrep.simxSetJointTargetPosition(clientID, listObjects(1).handle , Q(i,1), vrep.simx_opmode_oneshot);
    vrep.simxSetJointTargetPosition(clientID, listObjects(2).handle , Q(i,2), vrep.simx_opmode_oneshot);
    vrep.simxSetJointTargetPosition(clientID, listObjects(3).handle , Q(i,3), vrep.simx_opmode_oneshot);
    vrep.simxSetJointTargetPosition(clientID, listObjects(4).handle , Q(i,4), vrep.simx_opmode_oneshot);
    vrep.simxSetJointTargetPosition(clientID, listObjects(5).handle , Q(i,5), vrep.simx_opmode_oneshot);
    vrep.simxSetJointTargetPosition(clientID, listObjects(6).handle , Q(i,6), vrep.simx_opmode_oneshot);
    
    % r�active VREP et applique toutes les consignes simultan�ment
    vrep.simxPauseCommunication(clientID, 0);

    %Active 1 pas de simulation :
    vrep.simxSynchronousTrigger(clientID);
end 


%-----------------
% Simulation
%-----------------
% N=2000;       %Pas de simulation
q= [qf;0;0];
qc=[0;0;0;0;0;0;0;0];

% Croquis � dessiner
% PDD = {[100;100;0.01],[300;-100;0],[330;-50;0],[330;250;0],[300;300;0],[100;100;0], [300;167;0], [300;300;0], [330;250;0], [300;167;0], [330;100;0], [300;34;0], [330;-50;0], [300;-100;0], [300;34;0], [300;167;0], [300;34;0], [100;100;0]}; 
PDD = {[100;100;0],[300;-100;0],[300;100;0],[100;100;0]};
N=max(size(PDD));

% R�cup�ration position initiale
[T,P]= MGD_position(q, robot);    
Pe=P;

% Position d�sir�e
Pd =[100;100;20];

% Vitesse d�sir�e
Pd_dot = [1;1;1];

% Orientation d�sir�e
Ad = [-1 0 0;
       0 1 0;
       0 0 -1];
   
Kp= 3;              % Gain de r�activit� en postion
K0= 3;              % Gain de r�activit� en rotation

% Initialisation n�cessaire
Mux =[Pd - Pe; 0;0;0];
   
for i=1:N,
    % Evolution du point d�sir�
    Pd=PDD{i};
    
     while(equal(Pd,Pe,1,1))
%--------------------------G�n�ration de trajectoire----------------------%
norm(Pd - Pe)

        % Recup�ration de la position carth�sienne suivante � chaque dt
         if (norm(Pd - Pe) > 100 ) 

             Pinter = Pe + ((Pd - Pe)/norm(Pd - Pe)*(10e-2));
                        
             else if (norm(Pd - Pe) > 50 )
                         
                Pinter = Pe + (Pd - Pe)/norm(Pd - Pe);
                K0= 4; 
                Kp= 4;
                        
                    else if (norm(Pd - Pe) > 10 )

                        Pinter = Pe + ((Pd - Pe)/norm(Pd - Pe));
                        K0= 5; 
                        Kp= 5;

                        else if (norm(Pd - Pe) > 5 )

                            Pinter = Pe + ((Pd - Pe)/norm(Pd - Pe));
                            K0= 6; 
                            Kp= 6;
                            
                            else if (norm(Pd - Pe) > 1.5 )

                            Pinter = Pe + (Pd - Pe)/norm(Pd - Pe);
                            K0= 6; 
                            Kp= 6;
                            
                            else if (norm(Pd - Pe) > 1 )

                            K0= 3; 
                            Kp= 3;
                            break;
                            
                            end
                                end
                         
                            end
                        end
                 end
                 
                 end
         

        % Jacobienne
        J=Jacob(q, robot, Pinter);
        pseudo= pinv(J);

        % Vitesse
        q_dot= pseudo*Mux;

        for j=1:6,
            if (q_dot(j) > robot.dq(j)) 
                q_dot(j) = robot.dq(j);

            end
        end

        % Commande 
        q= q + q_dot*dt;

        for j=1:6,
            if (q(j) > robot.qmax(j)) 
                q(j) = robot.qmax(j);

            elseif (q(j) < robot.qmin(j)) 
                q(j) = robot.qmin(j);

            end
        end

        % MGD
        T= MGD(q, robot);
        Pe= T(1:3,4);        % Position r�elle
        Ae= T(1:3,1:3);      % Orientation r�elle

        % Erreur de position
        Ep= Pd - Pe;

        % Erreur d'orientation
        A= Ad*Ae';
        A0= [A(3,2) - A(2,3);
             A(1,3) - A(3,1);
             A(2,1) - A(1,2)];

        E0= 0.5*A0;

        % Laplacien inverse
        sechap= chap(Ae(1:3,1));
        sdchap= chap(Ad(1:3,1));

        nechap= chap(Ae(1:3,2));
        ndchap= chap(Ad(1:3,2));

        aechap= chap(Ae(1:3,3));
        adchap= chap(Ad(1:3,3));

        L= (-0.5)*(sechap*sdchap + nechap*ndchap + aechap*adchap);

        L_inv= pinv(L);

        % MUX
        Pe_dot = Pd_dot + Ep*Kp;
        We= L_inv*K0*E0;

        Mux =[Pe_dot; We];

        % lien client
        vrep.simxPauseCommunication(clientID, 1);
        % on envoit toutes les consignes
        vrep.simxSetJointTargetPosition(clientID, listObjects(1).handle , q(1), vrep.simx_opmode_oneshot);
        vrep.simxSetJointTargetPosition(clientID, listObjects(2).handle , q(2), vrep.simx_opmode_oneshot);
        vrep.simxSetJointTargetPosition(clientID, listObjects(3).handle , q(3), vrep.simx_opmode_oneshot);
        vrep.simxSetJointTargetPosition(clientID, listObjects(4).handle , q(4), vrep.simx_opmode_oneshot);
        vrep.simxSetJointTargetPosition(clientID, listObjects(5).handle , q(5), vrep.simx_opmode_oneshot);
        vrep.simxSetJointTargetPosition(clientID, listObjects(6).handle , q(6), vrep.simx_opmode_oneshot);

        % r�active VREP et applique toutes les consignes simultan�ment
        vrep.simxPauseCommunication(clientID, 0);

        %Active 1 pas de simulation :
        vrep.simxSynchronousTrigger(clientID);

        %lecture des position dans vrep
        [err(1), q(1)]=vrep.simxGetJointPosition(clientID, listObjects(1).handle, vrep.simx_opmode_oneshot);
        [err(2), q(2)]=vrep.simxGetJointPosition(clientID, listObjects(2).handle, vrep.simx_opmode_oneshot);
        [err(3), q(3)]=vrep.simxGetJointPosition(clientID, listObjects(3).handle, vrep.simx_opmode_oneshot);
        [err(4), q(4)]=vrep.simxGetJointPosition(clientID, listObjects(4).handle, vrep.simx_opmode_oneshot);
        [err(5), q(5)]=vrep.simxGetJointPosition(clientID, listObjects(5).handle, vrep.simx_opmode_oneshot);
        [err(6), q(6)]=vrep.simxGetJointPosition(clientID, listObjects(6).handle, vrep.simx_opmode_oneshot);

    end
end

%-----------------
% D�pla�ement par Loi Polynomiale
%-----------------

% Initialisation des variables
duree=10;
qi= q(1:6);
qf=[0;0;0;0;0;0];

% Loi polynomiale
[param,Q] = Loi_polynomiale(robot,qf,qi, duree);

% Calcul de la longueur du vecteur 
M= max(size(Q));

for i=1:M,
    
     % lien client
    vrep.simxPauseCommunication(clientID, 1);
    % on envoit toutes les consignes
    vrep.simxSetJointTargetPosition(clientID, listObjects(1).handle , Q(i,1), vrep.simx_opmode_oneshot);
    vrep.simxSetJointTargetPosition(clientID, listObjects(2).handle , Q(i,2), vrep.simx_opmode_oneshot);
    vrep.simxSetJointTargetPosition(clientID, listObjects(3).handle , Q(i,3), vrep.simx_opmode_oneshot);
    vrep.simxSetJointTargetPosition(clientID, listObjects(4).handle , Q(i,4), vrep.simx_opmode_oneshot);
    vrep.simxSetJointTargetPosition(clientID, listObjects(5).handle , Q(i,5), vrep.simx_opmode_oneshot);
    vrep.simxSetJointTargetPosition(clientID, listObjects(6).handle , Q(i,6), vrep.simx_opmode_oneshot);
    
    % r�active VREP et applique toutes les consignes simultan�ment
    vrep.simxPauseCommunication(clientID, 0);

    %Active 1 pas de simulation :
    vrep.simxSynchronousTrigger(clientID);
end 

pause(2)
%Arrete le simulateur
vrep.simxStopSimulation(clientID,vrep.simx_opmode_oneshot_wait);

% Ferme la connexion r�seau � VREP
vrep.simxFinish(-1);

vrep.delete();
