% MGD affich
function T=MGD_affich(teta, robot)
    
    N=max(size(robot.alpha));
    Tp=eye(4);
    X=zeros(4,4);
    
%   Calcul avec formule:
    for i=1:6
        T=Tp*Rotx(robot.alpha(i))*Transx(robot.d(i))*Rotz(teta(i))*Transz(robot.r(i));
       
        points(i,1:3)= T(1:3,4)';
        
        Tp=T;
         
    end
    
    T= Tp*Rotx(0)*Transx(0)*Rotz(pi)*Transz(123);
    points(7,1:3)= T(1:3,4)';
     
    T= Tp*Rotx(0)*Transx(0)*Rotz(0)*Transz(112);
    points(8,1:3)= T(1:3,4)';
    
    joints = [1 2;2 3;3 4;4 5;5 6;6 7;7 8;8 9];
    aff_rob = patch('vertices', points, 'faces', joints);
end

           