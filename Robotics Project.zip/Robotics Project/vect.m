function seg = vect(origine,x,z)
    
    seg = origine + [x;0;z;1];

end