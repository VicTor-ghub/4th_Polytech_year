
function Q = CalculeQ(robot,qf,qi, param, T)
    
    p=1;
    
    for t=0:0.1:T
        for i=1:6 
            if (t < param.t1_max)

                    Q(p,i)= qi(i) + 0.5*param.Amax_prime(i)*t^2;

            elseif ( param.t1_max < t && t <= param.duree - param.t1_max)

                    Q(p,i)= qi(i) + (t-param.t1_max/2)*param.Vmax_prime(i);

            elseif ( param.duree - param.t1_max < t && t <= param.duree)

                    Q(p,i)= qf(i) - 0.5*(param.duree - t)^2*param.Amax_prime(i);
            end
        end
        p= p+1;
    end
end