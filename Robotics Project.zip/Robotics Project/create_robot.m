%Cr�ation d'un robot Robotis-H 

function [teta, robot] = create_robot(teta1,teta2,teta3,teta4,teta5,teta6)

    %Commande 
    q0=[teta1; teta2; teta3; teta4; teta5; teta6];
    teta=q0;
    robot.alpha=[0; -pi/2; 0; -pi/2; pi/2; -pi/2];
    robot.r=[159; 0; 0; 258; 0; 0];
    robot.d=[0; 0; 265.69; 30; 0; 0];
    
    robot.qmin=[-pi ; -pi/2;  -pi/2  ; -pi ; -pi/2  ; -pi ];
    robot.qmax=[ pi ; pi/2 ;  3*pi/4 ; pi  ;  pi/2  ; pi];
    robot.dq=[3.3; 3.3; 3.3; 3.3; 3.2; 3.2 ];
    robot.d2q=[30; 30; 30; 30; 30; 30];
    robot.Cmax=[44.2; 44.2; 21.142; 21.142; 6.3; 6.3];
    
end