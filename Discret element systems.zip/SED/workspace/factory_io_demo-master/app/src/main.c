/*
 * main.c
 *
 *  Created on: 16 ao�t 2018
 *      Author: Laurent
 */

#include "stm32f0xx.h"
#include "main.h"
#include "bsp.h"
#include "factory_io.h"
#include "delay.h"


/*
 * Local Static Functions
 */

static uint8_t 	SystemClock_Config	(void);


/*
 * Actuators define
 */

#define Distrib_C 1
#define Tapis_Distrib_C 1 << 1
#define Blocage_Palettiseur 1 << 2
#define Porte 1 << 3
#define Poussoir 1 << 4
#define Clamp 1 << 5
#define Monter_asc 1 << 6
#define Descendre_asc 1 << 8
#define Asc_to_limit 1 << 9
#define Distrib_P 1 << 10
#define Charger_P 1 << 11
#define Tapis_C_vers_Palettiseur 1 << 12
#define Tourner_C 1 << 13
#define Decharger_Palettiseur 1 << 14
#define Charger_Palettiseur 1 << 16
#define Decharger_P 1 << 17
#define Tapis_Palette_vers_asc 1 << 18
#define Tapis_distrib_P 1 << 19
#define Tapis_Fin 1 << 20
#define Remover 1 << 21

/*
 * Sensors define
 */

#define Carton_distrib 1
#define Carton_envoye 1 << 1
#define Entree_Palletiseur 1 << 2
#define Porte_ouverte 1 << 3
#define Limite_poussoir 1 << 4
#define Clamped 1 << 5
#define Asc_etage_rdc 1 << 6
#define Asc_etage_1 1 << 8
#define Asc_etage_2 1 << 9
#define Sortie_P 1 << 10
#define Limite_porte 1 << 11
#define Asc_en_mvt 1 << 12
#define Entree_P 1 << 13
#define Butee_C 1 << 14

/*
 * Project Entry Point
 */

int main(void)
{
	/*
	 * Variables
	 */
	uint32_t act_buffer ;
	//Entities
	int state_distrib_C = 1;
	int state_comptage_C = 1;
	int state_palettiseur = 1;
	int state_distrib_P = 1;
	int state_asc = 1;
	int state_Pi = 1;
	int state_Po = 1;
	//Memory
	int premier_carton = 1;
	int deuxieme_carton = 0;
	int first = 1;
	int second = 0;
	//Compteur
	int cnt = 0;
	int decnt = 3;
	//Alternance
	int alt1 = 1;
	int alt2 = 0;
	//Synchros
	int Sync_demande2C = 0;
	int Sync_deblocage = 0;
	int Sync_palettiseur = 0;
	int Sync_clamp = 0;
	int Sync_asc = 0;
	int Sync_end = 0;
	int Sync_ascenseur_clamp  = 0;
	int Sync_declamp = 0;
	int Sync_CandP = 0;
	int P_openandC_lacher = 0;
	int Sync_asc_descendu = 0;

	// Configure System Clock for 48MHz from 8MHz HSE
	SystemClock_Config();

	// Initialize LED and USER Button
	BSP_LED_Init();
	BSP_PB_Init();

	// Initialize Debug Console
	BSP_Console_Init();
	my_printf("\r\nConsole Ready!\r\n");
	my_printf("SYSCLK = %d Hz\r\n", SystemCoreClock);

	// Read all states from the scene
	FACTORY_IO_update();

	// Wait here for user button
	while(BSP_PB_GetState() == 0);

//	// Start conveyor A[0] = 1
//	my_printf("Starting Conveyor\r\n");
//	FACTORY_IO_Actuators_Set(0x00000001);
//
//	// Wait for sensor S[1] = 0 (optical barrier)
//	my_printf("Waiting for sensor...\r\n");
//	while (FACTORY_IO_Sensors_Get(0x00000002) == 1);
//
//	// Stop conveyor A[0] = 0
//	my_printf("Stop!\r\n");
//	FACTORY_IO_Actuators_Set(0x00000000);

	// Loop forever
	while(1)
	{
		// Initialization
		act_buffer = 0;
		act_buffer |= Tapis_Distrib_C | Tapis_C_vers_Palettiseur | Charger_Palettiseur | Tapis_distrib_P | Blocage_Palettiseur | Tapis_Palette_vers_asc | Remover | Tapis_Fin;

		//Entity 1 : Distribution des cartons
		switch (state_distrib_C)
		{
		case 1: // Distribution carton
			act_buffer |= Distrib_C;
			if (FACTORY_IO_Sensors_Get(Carton_distrib) == 0)
			{
				state_distrib_C ++;
			}
			break;

		case 2: // Attente_distrib
			if (FACTORY_IO_Sensors_Get(Carton_envoye) == 0)
			{
				state_distrib_C ++;
			}
			break;
		case 3: // Memory
			if (premier_carton)
			{
				premier_carton = 0;
				deuxieme_carton = 1;
				state_distrib_C = 1;
			}
			else if (deuxieme_carton)
			{
				premier_carton = 1;
				deuxieme_carton = 0;
				state_distrib_C ++;
				Sync_deblocage = 1;
			}
			break;

		case 4: // Attente_Tapis_Dispo
			if (Sync_demande2C)
			{
				Sync_demande2C = 0;
				state_distrib_C = 1;
			}
			break;
		}


		//Entity 2 : Comptage des cartons / Déblocage
		switch (state_comptage_C)
		{
		case 1: // Wait_debloc
			if (Sync_deblocage)
			{
				state_comptage_C ++;
				Sync_deblocage = 0;
			}
			break;

		case 2: // Arrivé_carton
			if (FACTORY_IO_Sensors_Get(Entree_Palletiseur) == 0)
			{
				state_comptage_C ++;
			}
			break;

		case 3: // Memory
			if (first && (FACTORY_IO_Sensors_Get(Entree_Palletiseur) == 1) )
			{
				first = 0;
				second = 1;
				state_comptage_C = 2;
			}
			else if (second)
			{
				first = 1;
				second = 0;
				state_comptage_C ++;
			}
			break;

		case 4: // Déblocage
			act_buffer &= ~Blocage_Palettiseur;
			if(FACTORY_IO_Sensors_Get(Butee_C))
			{
				Sync_palettiseur = 1;
				state_comptage_C = 1;
			}
			break;
		}

		//Entity 3 : Palettiseur
		switch (state_palettiseur)
		{
		case 1: // Demande_poussoir
			if (Sync_palettiseur)
			{
				state_palettiseur ++;
				Sync_palettiseur = 0;
			}
			break;

		case 2: // Poussoir
			act_buffer |= Poussoir;
			if (FACTORY_IO_Sensors_Get(Limite_poussoir) == 1 && (FACTORY_IO_Sensors_Get(Butee_C) == 0) )
			{
				state_palettiseur ++;
			}
			break;

		case 3: // Compteur
			if ((decnt > 1) )
			{
				decnt --;
				cnt ++ ;
				state_palettiseur = 1;
				Sync_demande2C = 1;
			}
			else if (cnt == 2)
			{
				decnt = 3;
				cnt = 0;
				state_palettiseur = 1;
				Sync_clamp = 1;
			}
			break;
		}

		//Entity 4 : Distribution des palettes
		switch (state_distrib_P)
		{
		case 1: // Distribution palette
			act_buffer |= Distrib_P;
			state_distrib_P ++;
			break;

		case 2: // Charger_palette
			act_buffer |= Charger_P;
			if (FACTORY_IO_Sensors_Get(Sortie_P))
			{
				state_distrib_P ++;
				Sync_asc = 1;
			}
			break;

		case 3: // Attente_retour
			if (Sync_end )
			{
				if (FACTORY_IO_Sensors_Get(Sortie_P))
				{
					state_distrib_P ++;
					Sync_end = 0;
				}
			}
			break;

		case 4: // Décharger palette
			act_buffer |= Charger_P;
			if (FACTORY_IO_Sensors_Get(Sortie_P) == 0)
			{
				state_distrib_P = 1;
			}
			break;
		}

		//Entity 5 : Ascenseur
		switch (state_asc)
		{
		case 1: // Attente palette
			if (Sync_asc)
			{
				state_asc ++;
				Sync_asc = 0;
			}
			break;

		case 2: // Monter ascenseur
			act_buffer |= Monter_asc | Asc_to_limit;
			if (FACTORY_IO_Sensors_Get(Asc_etage_1) )
			{
				state_asc ++;
			}
			break;

		case 3: // Envoi_demande
			state_asc ++;
			Sync_ascenseur_clamp = 1;
			break;

		case 4: //Attente_declamped
			if ((Sync_declamp))
			{
				state_asc ++;
				Sync_demande2C = 1;
				Sync_declamp= 0;
			}
			break;

		case 5: //Alternance
			if (alt1)
			{
				alt1 = 0;
				alt2 = 1;
				state_asc ++;
			}
			else if (alt2)
			{
				alt1 = 1;
				alt2 = 0;
				state_asc = 7;
			}
			break;

		case 6: // Descendre ascenseur
			act_buffer |= Descendre_asc;
			if ( FACTORY_IO_Sensors_Get(Asc_etage_2) && (FACTORY_IO_Sensors_Get(Asc_etage_1) == 0) && (FACTORY_IO_Sensors_Get(Asc_en_mvt) == 0) )
			{
				state_asc = 3;
				Sync_asc_descendu = 1;
			}
			break;

		case 7: // Descendre ascenseur to limit
			act_buffer |= Descendre_asc | Asc_to_limit;
			if (FACTORY_IO_Sensors_Get(Asc_etage_rdc) && (FACTORY_IO_Sensors_Get(Asc_en_mvt) == 0))
			{
				state_asc = 1;
				Sync_asc_descendu = 1;
				Sync_end = 1;
			}
			break;
		}
		//Entity 6 : Pince
		switch (state_Pi)
		{
		case 1: // Demande clamp
			if (Sync_clamp && Sync_ascenseur_clamp )
			{
				state_Pi ++;
				Sync_clamp = 0;
				Sync_ascenseur_clamp = 0;
				Sync_CandP = 1;
			}
			break;

		case 2: // Clamp
			act_buffer |= Clamp;
			if (P_openandC_lacher && FACTORY_IO_Sensors_Get(Clamped))
			{
				state_Pi =1;
				P_openandC_lacher= 0;
				Sync_declamp = 1;
			}
			break;
		}

		//Entity 7 : Porte
		switch (state_Po)
		{
		case 1: // Demande porte
			if (Sync_CandP)
			{
				state_Po ++;
				Sync_CandP= 0;
			}
			break;

		case 2: // Porte
			act_buffer |= Porte;
			if (FACTORY_IO_Sensors_Get(Porte_ouverte) && FACTORY_IO_Sensors_Get(Limite_porte) )
			{
				state_Po ++;
				P_openandC_lacher = 1;

			}
			break;

		case 3: // stay_porte_open
			act_buffer |= Porte;
			if (FACTORY_IO_Sensors_Get(Porte_ouverte) && FACTORY_IO_Sensors_Get(Limite_porte) && Sync_asc_descendu)
			{
				state_Po = 1;
				Sync_asc_descendu= 0;
			}
			break;

		}
		// Refresh
		FACTORY_IO_Actuators_Set(act_buffer);

		// LED blinking
		BSP_LED_Toggle();
		delay_ms(100);
	}
}



/*
 * 	Clock configuration for the Nucleo STM32F072RB board
 * 	HSE input Bypass Mode 			-> 8MHz
 * 	SYSCLK, AHB, APB1 				-> 48MHz
 *  PA8 as MCO with /16 prescaler 	-> 3MHz
 */

static uint8_t SystemClock_Config()
{
	uint32_t	status;
	uint32_t	timeout;

	// Start HSE in Bypass Mode
	RCC->CR |= RCC_CR_HSEBYP;
	RCC->CR |= RCC_CR_HSEON;

	// Wait until HSE is ready
	timeout = 1000;

	do
	{
		status = RCC->CR & RCC_CR_HSERDY_Msk;
		timeout--;
	} while ((status == 0) && (timeout > 0));

	if (timeout == 0) return (1);	// HSE error


	// Select HSE as PLL input source
	RCC->CFGR &= ~RCC_CFGR_PLLSRC_Msk;
	RCC->CFGR |= (0x02 <<RCC_CFGR_PLLSRC_Pos);

	// Set PLL PREDIV to /1
	RCC->CFGR2 = 0x00000000;

	// Set PLL MUL to x6
	RCC->CFGR &= ~RCC_CFGR_PLLMUL_Msk;
	RCC->CFGR |= (0x04 <<RCC_CFGR_PLLMUL_Pos);

	// Enable the main PLL
	RCC-> CR |= RCC_CR_PLLON;

	// Wait until PLL is ready
	timeout = 1000;

	do
	{
		status = RCC->CR & RCC_CR_PLLRDY_Msk;
		timeout--;
	} while ((status == 0) && (timeout > 0));

	if (timeout == 0) return (2);	// PLL error


	// Set AHB prescaler to /1
	RCC->CFGR &= ~RCC_CFGR_HPRE_Msk;
	RCC->CFGR |= RCC_CFGR_HPRE_DIV1;

	//Set APB1 prescaler to /1
	RCC->CFGR &= ~RCC_CFGR_PPRE_Msk;
	RCC->CFGR |= RCC_CFGR_PPRE_DIV1;

	// Enable FLASH Prefetch Buffer and set Flash Latency (required for high speed)
	FLASH->ACR = FLASH_ACR_PRFTBE | FLASH_ACR_LATENCY;

	// Select the main PLL as system clock source
	RCC->CFGR &= ~RCC_CFGR_SW;
	RCC->CFGR |= RCC_CFGR_SW_PLL;

	// Wait until PLL becomes main switch input
	timeout = 1000;

	do
	{
		status = (RCC->CFGR & RCC_CFGR_SWS_Msk);
		timeout--;
	} while ((status != RCC_CFGR_SWS_PLL) && (timeout > 0));

	if (timeout == 0) return (3);	// SW error


	// Set MCO source as SYSCLK (48MHz)
	RCC->CFGR &= ~RCC_CFGR_MCO_Msk;
	RCC->CFGR |=  RCC_CFGR_MCOSEL_SYSCLK;

	// Set MCO prescaler to /16 -> 3MHz
	RCC->CFGR &= ~RCC_CFGR_MCOPRE_Msk;
	RCC->CFGR |=  RCC_CFGR_MCOPRE_DIV16;

	// Enable GPIOA clock
	RCC->AHBENR |= RCC_AHBENR_GPIOAEN;

	// Configure PA8 as Alternate function
	GPIOA->MODER &= ~GPIO_MODER_MODER8_Msk;
	GPIOA->MODER |= (0x02 <<GPIO_MODER_MODER8_Pos);

	// Set to AF0 (MCO output)
	GPIOA->AFR[1] &= ~(0x0000000F);
	GPIOA->AFR[1] |=  (0x00000000);

	// Update SystemCoreClock global variable
	SystemCoreClockUpdate();
	return (0);
}
